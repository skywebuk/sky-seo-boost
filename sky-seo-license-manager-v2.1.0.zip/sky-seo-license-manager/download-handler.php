<?php
/**
 * Sky SEO Plugin Secure Download Handler
 * Serves plugin files only to authorized requests
 */

// Prevent any output before headers
if (ob_get_level()) {
    ob_end_clean();
}

// Load WordPress
$wp_load_paths = [
    dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php',
    dirname(dirname(dirname(__FILE__))) . '/wp-load.php',
    $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php',
    '../../../../wp-load.php',
    '../../../wp-load.php'
];

$wp_loaded = false;
foreach ($wp_load_paths as $path) {
    if (file_exists($path)) {
        require_once($path);
        $wp_loaded = true;
        break;
    }
}

if (!$wp_loaded) {
    header('HTTP/1.1 500 Internal Server Error');
    die('WordPress not found');
}

// Initialize database manager if available for consistent domain normalization
if (!class_exists('Sky_License_Database_Manager')) {
    $manager_path = WP_PLUGIN_DIR . '/sky-seo-license-manager/includes/class-database-manager.php';
    if (file_exists($manager_path)) {
        require_once($manager_path);
    }
}

// Get request data from multiple sources
$license = '';
$domain = '';

// Try to get from POST data first
if (!empty($_POST['license'])) {
    $license = sanitize_text_field($_POST['license']);
}
if (!empty($_POST['domain'])) {
    $domain = sanitize_text_field($_POST['domain']);
}

// Fall back to GET parameters
if (empty($license) && !empty($_GET['license'])) {
    $license = sanitize_text_field($_GET['license']);
}
if (empty($domain) && !empty($_GET['domain'])) {
    $domain = sanitize_text_field($_GET['domain']);
}

// Fall back to REQUEST
if (empty($license) && !empty($_REQUEST['license'])) {
    $license = sanitize_text_field($_REQUEST['license']);
}
if (empty($domain) && !empty($_REQUEST['domain'])) {
    $domain = sanitize_text_field($_REQUEST['domain']);
}

// Function to exit with error
function download_error($message) {
    header('HTTP/1.1 403 Forbidden');
    header('Content-Type: text/plain; charset=utf-8');
    die($message);
}

// Check if we have license and domain
if (empty($license) || empty($domain)) {
    download_error('Missing license or domain');
}

// Validate license in database
global $wpdb;
$license_table = $wpdb->prefix . 'sky_seo_licenses';

// Check if table exists
if ($wpdb->get_var("SHOW TABLES LIKE '$license_table'") != $license_table) {
    download_error('License system not configured');
}

// Normalize domain using centralized method if available
if (class_exists('Sky_License_Database_Manager')) {
    $db_manager = new Sky_License_Database_Manager();
    $domain = $db_manager->normalize_domain($domain);
} else {
    // Fallback normalization
    $domain = strtolower(trim($domain));
    $domain = preg_replace('#^https?://#', '', $domain);
    $domain = preg_replace('#^www\.#', '', $domain);
    $domain = rtrim($domain, '/');
    $domain = preg_replace('#:\d+$#', '', $domain); // Remove port
}

// Get license with row lock to prevent race conditions
$wpdb->query('START TRANSACTION');

try {
    // Get license with row lock
    $license_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $license_table WHERE license_key = %s FOR UPDATE",
        $license
    ));
    
    if (!$license_data) {
        $wpdb->query('ROLLBACK');
        download_error('Invalid license');
    }
    
    // Check if license is active
    if ($license_data->status !== 'active') {
        $wpdb->query('ROLLBACK');
        download_error('License is not active');
    }
    
    // Check domain match
    if (class_exists('Sky_License_Database_Manager')) {
        $domain_matches = $db_manager->domains_match($license_data->domain, $domain);
    } else {
        // Fallback domain matching
        $license_domain = strtolower(trim($license_data->domain));
        $license_domain = preg_replace('#^www\.#', '', $license_domain);
        $domain_matches = ($license_domain === $domain || $license_domain === '*');
    }
    
    if (!$domain_matches) {
        $wpdb->query('ROLLBACK');
        download_error('Domain mismatch');
    }
    
    // Check expiration
    if (!empty($license_data->expires_at) && $license_data->expires_at !== '0000-00-00 00:00:00') {
        if (strtotime($license_data->expires_at) < time()) {
            $wpdb->query('ROLLBACK');
            download_error('License expired');
        }
    }
    
    // Update last check time
    $wpdb->update(
        $license_table,
        ['last_check' => current_time('mysql')],
        ['id' => $license_data->id]
    );
    
    // Commit the transaction
    $wpdb->query('COMMIT');
    
} catch (Exception $e) {
    $wpdb->query('ROLLBACK');
    download_error('Database error: ' . $e->getMessage());
}

// Get plugin file path
$plugin_file_path = get_option('sky_seo_boost_file_path');

// Default to a plugins directory location if not set
if (empty($plugin_file_path)) {
    $upload_dir = wp_upload_dir();
    $plugin_file_path = $upload_dir['basedir'] . '/sky-licenses/sky-seo-boost.zip';
}

// Check if file exists and is readable
if (!file_exists($plugin_file_path)) {
    download_error('Plugin file not found');
}

if (!is_readable($plugin_file_path)) {
    download_error('Plugin file not readable');
}

// Get file size
$file_size = filesize($plugin_file_path);
if ($file_size === false || $file_size == 0) {
    download_error('Invalid plugin file size');
}

// Disable compression to ensure clean file transfer
if (function_exists('apache_setenv')) {
    @apache_setenv('no-gzip', '1');
}
@ini_set('zlib.output_compression', 'Off');

// Clear any existing output buffers
while (ob_get_level()) {
    ob_end_clean();
}

// Set headers for file download
header('Content-Description: File Transfer');
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="sky-seo-boost.zip"');
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' . $file_size);
header('Connection: close');

// Disable time limit for large files
@set_time_limit(0);
@ini_set('memory_limit', '256M');

// Open file for reading
$fp = @fopen($plugin_file_path, 'rb');
if ($fp === false) {
    download_error('Cannot open plugin file for reading');
}

// Output file in chunks to avoid memory issues
$chunk_size = 8192; // 8KB chunks

while (!feof($fp) && connection_status() == 0) {
    $chunk = fread($fp, $chunk_size);
    if ($chunk === false) {
        break;
    }
    
    echo $chunk;
    
    // Flush output to browser
    if (ob_get_level() > 0) {
        @ob_flush();
    }
    @flush();
}

fclose($fp);
exit;