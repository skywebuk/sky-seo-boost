<?php
/**
 * Sky SEO Plugin Update Handler
 * Handles update requests and serves updates only to licensed users
 * NOW WITH CRYPTOGRAPHIC SIGNATURE SUPPORT
 * 
 * @package Sky_SEO_License_Manager
 * @version 2.0.0
 */

// Prevent any output before headers
if (ob_get_level()) {
    ob_end_clean();
}

// Load WordPress
$wp_load_path = dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php';
if (file_exists($wp_load_path)) {
    require_once($wp_load_path);
} else {
    require_once('../../../../wp-load.php');
}

// Set proper headers to prevent connection issues
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Connection: close');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Function to send JSON response with proper headers
function send_json_response($data, $status_code = 200) {
    if (ob_get_level()) {
        ob_clean();
    }
    
    http_response_code($status_code);
    $json_response = json_encode($data);
    header('Content-Length: ' . strlen($json_response));
    echo $json_response;
    exit;
}

// Load signature generator class
$signature_generator_path = dirname(__FILE__) . '/includes/class-signature-generator.php';
if (file_exists($signature_generator_path)) {
    require_once($signature_generator_path);
    $signature_available = true;
} else {
    $signature_available = false;
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log('Update Handler: Signature generator not found - responses will be unsigned');
    }
}

// Get POST data
$input = file_get_contents('php://input');
$post_data = [];

if (!empty($input)) {
    $json_data = json_decode($input, true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($json_data)) {
        $post_data = $json_data;
    }
}

// Fall back to $_POST if no JSON data
if (empty($post_data)) {
    $post_data = $_POST;
}

$license = isset($post_data['license']) ? sanitize_text_field($post_data['license']) : '';
$domain = isset($post_data['domain']) ? sanitize_text_field($post_data['domain']) : '';
$current_version = isset($post_data['version']) ? sanitize_text_field($post_data['version']) : '';
$plugin_slug = isset($post_data['slug']) ? sanitize_text_field($post_data['slug']) : 'sky-seo-boost';

// Initialize database manager for consistent domain normalization
if (!class_exists('Sky_License_Database_Manager')) {
    require_once(SKY_LICENSE_MANAGER_INCLUDES_DIR . 'class-database-manager.php');
}
$db_manager = new Sky_License_Database_Manager();

// Check if license is provided
if (empty($license) || empty($domain)) {
    $response_data = [
        'success' => false,
        'error' => 'License key required for updates'
    ];
    
    // Sign error response if available
    if ($signature_available && class_exists('Sky_License_Signature_Generator')) {
        $response_data = Sky_License_Signature_Generator::sign_response($response_data);
    }
    
    send_json_response($response_data, 400);
}

// Validate license
global $wpdb;
$license_table = $wpdb->prefix . 'sky_seo_licenses';

// Use centralized domain normalization
$domain = $db_manager->normalize_domain($domain);

// Check if license table exists
if ($wpdb->get_var("SHOW TABLES LIKE '$license_table'") != $license_table) {
    $response_data = [
        'success' => false,
        'error' => 'License system not properly configured'
    ];
    
    // Sign error response if available
    if ($signature_available && class_exists('Sky_License_Signature_Generator')) {
        $response_data = Sky_License_Signature_Generator::sign_response($response_data);
    }
    
    send_json_response($response_data, 500);
}

// Look up license
$license_data = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM $license_table WHERE license_key = %s",
    $license
));

if (!$license_data) {
    $response_data = [
        'success' => false,
        'error' => 'Invalid license key'
    ];
    
    // Sign error response if available
    if ($signature_available && class_exists('Sky_License_Signature_Generator')) {
        $response_data = Sky_License_Signature_Generator::sign_response($response_data);
    }
    
    send_json_response($response_data, 403);
}

// Check if license is active
if ($license_data->status !== 'active') {
    $response_data = [
        'success' => false,
        'error' => 'License is not active'
    ];
    
    // Sign error response if available
    if ($signature_available && class_exists('Sky_License_Signature_Generator')) {
        $response_data = Sky_License_Signature_Generator::sign_response($response_data);
    }
    
    send_json_response($response_data, 403);
}

// Check domain match using centralized method
if (!$db_manager->domains_match($license_data->domain, $domain)) {
    $response_data = [
        'success' => false,
        'error' => 'Domain mismatch'
    ];
    
    // Sign error response if available
    if ($signature_available && class_exists('Sky_License_Signature_Generator')) {
        $response_data = Sky_License_Signature_Generator::sign_response($response_data);
    }
    
    send_json_response($response_data, 403);
}

// Check expiration
if (!empty($license_data->expires_at) && $license_data->expires_at !== '0000-00-00 00:00:00') {
    if (strtotime($license_data->expires_at) < time()) {
        $response_data = [
            'success' => false,
            'error' => 'License has expired'
        ];
        
        // Sign error response if available
        if ($signature_available && class_exists('Sky_License_Signature_Generator')) {
            $response_data = Sky_License_Signature_Generator::sign_response($response_data);
        }
        
        send_json_response($response_data, 403);
    }
}

// Update last check time
$wpdb->update(
    $license_table,
    ['last_check' => current_time('mysql')],
    ['id' => $license_data->id]
);

// Get update information from options
$update_info = get_option('sky_seo_boost_update_info', [
    'version' => '4.1.0',
    'download_url' => '',
    'info_url' => 'https://skywebdesign.co.uk/plugins/sky-seo-boost',
    'tested' => '6.7',
    'requires' => '5.8',
    'requires_php' => '7.4',
    'changelog' => 'Version 4.1.0: Bug fixes and performance improvements.'
]);

// Check if update is needed
if (version_compare($current_version, $update_info['version'], '<')) {
    // Generate download URL with license and domain
    $download_url = add_query_arg([
        'license' => $license,
        'domain' => $domain
    ], SKY_LICENSE_MANAGER_PLUGIN_URL . 'download-handler.php');
    
    // Prepare update response
    $response_data = [
        'success' => true,
        'update_available' => true,
        'version' => $update_info['version'],
        'download_url' => $download_url,
        'info_url' => $update_info['info_url'],
        'tested' => $update_info['tested'],
        'requires' => $update_info['requires'],
        'requires_php' => $update_info['requires_php'],
        'changelog' => $update_info['changelog']
    ];
    
    // Add package info (for WordPress updater compatibility)
    $response_data['package'] = $download_url;
    $response_data['new_version'] = $update_info['version'];
    $response_data['slug'] = $plugin_slug;
    
    // Add optional upgrade notice if available
    if (!empty($update_info['upgrade_notice'])) {
        $response_data['upgrade_notice'] = $update_info['upgrade_notice'];
    }
    
    // Add optional sections (description, installation, etc.)
    if (!empty($update_info['sections'])) {
        $response_data['sections'] = $update_info['sections'];
    }
    
    // Add banners/icons if available
    if (!empty($update_info['banners'])) {
        $response_data['banners'] = $update_info['banners'];
    }
    
    if (!empty($update_info['icons'])) {
        $response_data['icons'] = $update_info['icons'];
    }
    
    // CRITICAL: Sign the response with cryptographic signature
    if ($signature_available && class_exists('Sky_License_Signature_Generator')) {
        $response_data = Sky_License_Signature_Generator::sign_response($response_data);

        // Verify signature was actually created
        if (!isset($response_data['signature']) || empty($response_data['signature'])) {
            error_log('Update Handler ERROR: Signature generation failed - signature field missing or empty');
            error_log('Response keys: ' . implode(', ', array_keys($response_data)));
            if (isset($response_data['signature_error'])) {
                error_log('Signature error: ' . $response_data['signature_error']);
            }
        } else {
            // Log successful signing in debug mode
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('Update Handler: Update response signed successfully for version ' . $update_info['version'] . ' (signature length: ' . strlen($response_data['signature']) . ' chars)');
            }
        }
    } else {
        // Log warning if signature not available
        error_log('Update Handler: WARNING - Update response sent without signature (signature generator unavailable)');
        error_log('Signature available: ' . ($signature_available ? 'yes' : 'no'));
        error_log('Class exists: ' . (class_exists('Sky_License_Signature_Generator') ? 'yes' : 'no'));
    }
    
    send_json_response($response_data);
    
} else {
    // No update available
    $response_data = [
        'success' => true,
        'update_available' => false,
        'message' => 'You have the latest version',
        'current_version' => $current_version,
        'latest_version' => $update_info['version']
    ];
    
    // Sign "no update" response
    if ($signature_available && class_exists('Sky_License_Signature_Generator')) {
        $response_data = Sky_License_Signature_Generator::sign_response($response_data);
        
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Update Handler: No update available response signed');
        }
    }
    
    send_json_response($response_data);
}