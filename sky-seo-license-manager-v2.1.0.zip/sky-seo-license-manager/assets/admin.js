jQuery(document).ready(function($) {
    // Form submission handler
    $('#sky-license-form').on('submit', function(e) {
        e.preventDefault();
        
        var $form = $(this);
        var $submitButton = $form.find('button[type="submit"]');
        
        // Disable submit button and show loading state
        $submitButton.prop('disabled', true).text('Saving...');
        
        const formData = {
            action: 'sky_license_save',
            nonce: skyLicenseManager.nonce,
            license_id: $('#license_id').val(),
            license_key: $('#license_key').val(),
            domain: $('#domain').val(),
            status: $('#status').val(),
            expires_at: $('#expires_at').val(),
            max_activations: $('#max_activations').val(),
            notes: $('#notes').val()
        };
        
        $.post(skyLicenseManager.ajaxurl, formData)
            .done(function(response) {
                if (response.success) {
                    showNotice('success', response.data.message);
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    showNotice('error', response.data.message || 'An error occurred');
                    $submitButton.prop('disabled', false).text('Save License');
                }
            })
            .fail(function(xhr) {
                showNotice('error', 'Network error. Please try again.');
                $submitButton.prop('disabled', false).text('Save License');
            });
    });
});

// Generate random license key
function generateLicenseKey() {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let key = '';
    
    for (let i = 0; i < 4; i++) {
        for (let j = 0; j < 4; j++) {
            key += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        if (i < 3) key += '-';
    }
    
    document.getElementById('license_key').value = key;
    
    // Show a notice that key was generated
    showNotice('info', 'License key generated');
}

// Edit license
function editLicense(id) {
    // Show loading state
    showLoadingOverlay();
    
    jQuery.post(skyLicenseManager.ajaxurl, {
        action: 'sky_license_get',
        nonce: skyLicenseManager.nonce,
        id: id
    })
    .done(function(response) {
        if (response.success) {
            const license = response.data;
            
            // Populate form fields
            jQuery('#license_id').val(license.id);
            jQuery('#license_key').val(license.license_key);
            jQuery('#domain').val(license.domain);
            jQuery('#status').val(license.status);
            jQuery('#max_activations').val(license.max_activations);
            jQuery('#notes').val(license.notes);
            
            if (license.expires_at && license.expires_at !== '0000-00-00 00:00:00') {
                // Convert MySQL datetime to datetime-local format
                const date = new Date(license.expires_at.replace(' ', 'T'));
                const localDateTime = date.toISOString().slice(0, 16);
                jQuery('#expires_at').val(localDateTime);
            }
            
            // Update form title
            jQuery('.sky-license-form h2').text('Edit License #' + license.id);
            
            // Scroll to form
            jQuery('html, body').animate({
                scrollTop: jQuery('.sky-license-form').offset().top - 50
            }, 500);
            
            hideLoadingOverlay();
        } else {
            showNotice('error', 'Failed to load license data');
            hideLoadingOverlay();
        }
    })
    .fail(function() {
        showNotice('error', 'Network error. Please try again.');
        hideLoadingOverlay();
    });
}

// Delete license
function deleteLicense(id) {
    if (!confirm('Are you sure you want to delete this license? This action cannot be undone.')) {
        return;
    }
    
    showLoadingOverlay();
    
    jQuery.post(skyLicenseManager.ajaxurl, {
        action: 'sky_license_delete',
        nonce: skyLicenseManager.nonce,
        id: id
    })
    .done(function(response) {
        if (response.success) {
            showNotice('success', response.data.message);
            setTimeout(function() {
                location.reload();
            }, 1000);
        } else {
            showNotice('error', response.data.message || 'Failed to delete license');
            hideLoadingOverlay();
        }
    })
    .fail(function() {
        showNotice('error', 'Network error. Please try again.');
        hideLoadingOverlay();
    });
}

// Toggle license status
function toggleLicense(id) {
    showLoadingOverlay();
    
    jQuery.post(skyLicenseManager.ajaxurl, {
        action: 'sky_license_toggle',
        nonce: skyLicenseManager.nonce,
        id: id
    })
    .done(function(response) {
        if (response.success) {
            location.reload();
        } else {
            showNotice('error', response.data.message || 'Failed to toggle license status');
            hideLoadingOverlay();
        }
    })
    .fail(function() {
        showNotice('error', 'Network error. Please try again.');
        hideLoadingOverlay();
    });
}

// Reset form
function resetForm() {
    document.getElementById('sky-license-form').reset();
    document.getElementById('license_id').value = '';
    jQuery('.sky-license-form h2').text('Add New License');
    
    // Clear any datetime field
    jQuery('#expires_at').val('');
    
    showNotice('info', 'Form reset');
}

// Copy API endpoint to clipboard
function copyApiEndpoint() {
    const apiUrl = skyLicenseManager.api_url;
    
    // Create temporary input element
    const tempInput = document.createElement('input');
    tempInput.style.position = 'absolute';
    tempInput.style.left = '-9999px';
    tempInput.value = apiUrl;
    document.body.appendChild(tempInput);
    
    // Select and copy
    tempInput.select();
    tempInput.setSelectionRange(0, 99999); // For mobile devices
    
    try {
        document.execCommand('copy');
        showNotice('success', 'API endpoint copied to clipboard!');
    } catch (err) {
        // Fallback for older browsers
        prompt('Copy the API endpoint:', apiUrl);
    }
    
    document.body.removeChild(tempInput);
}

// Show notice helper
function showNotice(type, message) {
    // Remove any existing notices
    jQuery('.sky-admin-notice').remove();
    
    const noticeClass = type === 'success' ? 'notice-success' : 
                       type === 'error' ? 'notice-error' : 
                       'notice-info';
    
    const notice = jQuery('<div>')
        .addClass('notice sky-admin-notice ' + noticeClass + ' is-dismissible')
        .html('<p>' + message + '</p>')
        .hide();
    
    jQuery('.wrap').prepend(notice);
    notice.slideDown();
    
    // Auto-dismiss after 5 seconds for success messages
    if (type === 'success') {
        setTimeout(function() {
            notice.slideUp(function() {
                jQuery(this).remove();
            });
        }, 5000);
    }
    
    // Make WordPress dismiss button work
    jQuery(document).trigger('wp-updates-notice-added');
}

// Show loading overlay
function showLoadingOverlay() {
    if (jQuery('.spinner-overlay').length === 0) {
        jQuery('body').append(
            '<div class="spinner-overlay">' +
                '<div class="spinner is-active" style="float: none; margin: 0;"></div>' +
            '</div>'
        );
    }
}

// Hide loading overlay
function hideLoadingOverlay() {
    jQuery('.spinner-overlay').remove();
}

// Initialize tooltips if needed
jQuery(document).ready(function($) {
    // Add tooltips to help icons
    $('.sky-help-tip').each(function() {
        $(this).tooltip({
            content: $(this).data('tip'),
            position: {
                my: 'center bottom-10',
                at: 'center top'
            }
        });
    });
    
    // Confirm before leaving page with unsaved changes
    let formChanged = false;
    
    $('#sky-license-form').on('change', 'input, select, textarea', function() {
        formChanged = true;
    });
    
    $('#sky-license-form').on('submit', function() {
        formChanged = false;
    });
    
    $(window).on('beforeunload', function() {
        if (formChanged) {
            return 'You have unsaved changes. Are you sure you want to leave?';
        }
    });
});