<?php
/**
 * Sky SEO License Validation Endpoint
 * Location: /sky-seo-licenses/licenses.php
 */

// Load WordPress - try multiple paths for compatibility
$wp_load_paths = [
    dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php',
    dirname(dirname(dirname(__FILE__))) . '/wp-load.php',
    $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php',
    '../../../../wp-load.php',
    '../../../wp-load.php'
];

$wp_loaded = false;
foreach ($wp_load_paths as $path) {
    if (file_exists($path)) {
        require_once($path);
        $wp_loaded = true;
        break;
    }
}

if (!$wp_loaded) {
    header('HTTP/1.1 500 Internal Server Error');
    header('Content-Type: application/json');
    die(json_encode([
        'authenticated' => false,
        'error' => 'WordPress environment could not be loaded'
    ]));
}

// Set JSON header
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Get POST data (handle both form data and JSON)
$input = file_get_contents('php://input');
$post_data = [];

if (!empty($input) && json_decode($input)) {
    $post_data = json_decode($input, true);
} else {
    $post_data = $_POST;
}

$license = isset($post_data['license']) ? sanitize_text_field($post_data['license']) : '';
$domain = isset($post_data['domain']) ? sanitize_text_field($post_data['domain']) : '';

// Check for required fields
if (empty($license) || empty($domain)) {
    echo json_encode([
        'authenticated' => false,
        'error' => 'Missing license key or domain'
    ]);
    exit;
}

// Connect to database
global $wpdb;
$table_name = $wpdb->prefix . 'sky_seo_licenses';

// Check if table exists
if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
    echo json_encode([
        'authenticated' => false,
        'error' => 'License system not properly configured'
    ]);
    exit;
}

// Initialize database manager to use its normalize_domain method
if (!class_exists('Sky_License_Database_Manager')) {
    $plugin_path = WP_PLUGIN_DIR . '/sky-seo-license-manager/includes/class-database-manager.php';
    if (file_exists($plugin_path)) {
        require_once($plugin_path);
    }
}

$db_manager = new Sky_License_Database_Manager();
$domain = $db_manager->normalize_domain($domain);

// Look up license
$license_data = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM $table_name WHERE license_key = %s",
    $license
));

if (!$license_data) {
    echo json_encode([
        'authenticated' => false,
        'error' => 'Invalid license key'
    ]);
    exit;
}

// Check if license is active
if ($license_data->status !== 'active') {
    echo json_encode([
        'authenticated' => false,
        'error' => 'License is ' . $license_data->status
    ]);
    exit;
}

// Check expiration
if (!empty($license_data->expires_at) && $license_data->expires_at !== '0000-00-00 00:00:00') {
    if (strtotime($license_data->expires_at) < time()) {
        echo json_encode([
            'authenticated' => false,
            'error' => 'License has expired'
        ]);
        exit;
    }
}

// Use centralized domain matching
if (!$db_manager->domains_match($license_data->domain, $domain)) {
    echo json_encode([
        'authenticated' => false,
        'error' => 'Domain mismatch',
        'debug_info' => [
            'license_domain' => $license_data->domain,
            'request_domain' => $domain
        ]
    ]);
    exit;
}

// Update last check time
$wpdb->update(
    $table_name,
    ['last_check' => current_time('mysql')],
    ['id' => $license_data->id]
);

// Success! Return authenticated response
echo json_encode([
    'authenticated' => true,
    'domain' => $domain,
    'expires_at' => $license_data->expires_at
]);