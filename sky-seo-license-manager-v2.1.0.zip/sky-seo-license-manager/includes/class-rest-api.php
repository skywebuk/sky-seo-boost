<?php
/**
 * Sky SEO License Manager - REST API Endpoint
 *
 * Provides WordPress REST API endpoints as an alternative to direct file access.
 * This helps bypass hosting restrictions that may block direct PHP file access.
 *
 * @package Sky_SEO_License_Manager
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Sky_License_REST_API {

    /**
     * REST API namespace
     */
    const NAMESPACE = 'sky-license/v1';

    /**
     * Database manager instance
     */
    private $db_manager;

    /**
     * Constructor
     */
    public function __construct($db_manager) {
        $this->db_manager = $db_manager;
    }

    /**
     * Register REST API routes
     */
    public function register_routes() {
        // License validation endpoint
        register_rest_route(self::NAMESPACE, '/validate', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'validate_license'],
            'permission_callback' => '__return_true', // Public endpoint
            'args' => [
                'license' => [
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'description' => 'License key to validate',
                ],
                'domain' => [
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'description' => 'Domain to validate against',
                ],
            ],
        ]);

        // Update check endpoint
        register_rest_route(self::NAMESPACE, '/update-check', [
            'methods' => ['GET', 'POST'],
            'callback' => [$this, 'check_update'],
            'permission_callback' => '__return_true',
            'args' => [
                'license' => [
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'domain' => [
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ],
                'version' => [
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'default' => '0.0.0',
                ],
            ],
        ]);

        // Health check endpoint (for diagnostics)
        register_rest_route(self::NAMESPACE, '/health', [
            'methods' => 'GET',
            'callback' => [$this, 'health_check'],
            'permission_callback' => '__return_true',
        ]);
    }

    /**
     * Validate license via REST API
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response Response object
     */
    public function validate_license($request) {
        $license = $request->get_param('license');
        $domain = $request->get_param('domain');

        // Log the request for debugging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log(sprintf(
                'Sky License REST API: Validation request - License: %s****, Domain: %s',
                substr($license, 0, 4),
                $domain
            ));
        }

        // Normalize domain
        $domain = $this->db_manager->normalize_domain($domain);

        if (empty($domain)) {
            return $this->send_error_response(
                'Invalid domain format',
                'INVALID_DOMAIN',
                400
            );
        }

        // Get license from database
        $license_data = $this->db_manager->get_license_by_key($license);

        if (!$license_data) {
            return $this->send_error_response(
                'Invalid license key',
                'INVALID_LICENSE',
                403
            );
        }

        // Check status
        if ($license_data->status !== 'active') {
            return $this->send_error_response(
                'License is ' . $license_data->status,
                'LICENSE_' . strtoupper($license_data->status),
                403
            );
        }

        // Check expiration
        if (!empty($license_data->expires_at) && $license_data->expires_at !== '0000-00-00 00:00:00') {
            if (strtotime($license_data->expires_at) < time()) {
                return $this->send_error_response(
                    'License has expired',
                    'LICENSE_EXPIRED',
                    403
                );
            }
        }

        // Check domain match
        if (!$this->db_manager->domains_match($license_data->domain, $domain)) {
            return $this->send_error_response(
                'Domain not authorized for this license',
                'DOMAIN_MISMATCH',
                403,
                [
                    'license_domain' => $this->db_manager->normalize_domain($license_data->domain),
                    'request_domain' => $domain,
                ]
            );
        }

        // Update last check timestamp
        $this->db_manager->update_last_check($license_data->id);

        // Build success response
        $response_data = [
            'authenticated' => true,
            'status' => 'active',
            'domain' => $domain,
        ];

        // Add expiration info
        if (!empty($license_data->expires_at) && $license_data->expires_at !== '0000-00-00 00:00:00') {
            $response_data['expires_at'] = $license_data->expires_at;
            $response_data['days_remaining'] = max(0, floor((strtotime($license_data->expires_at) - time()) / 86400));
        }

        // Sign the response if signature generator is available
        $response_data = $this->sign_response($response_data);

        return new WP_REST_Response($response_data, 200);
    }

    /**
     * Check for updates via REST API
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response Response object
     */
    public function check_update($request) {
        $license = $request->get_param('license');
        $domain = $request->get_param('domain');
        $current_version = $request->get_param('version');

        // First validate the license
        $domain = $this->db_manager->normalize_domain($domain);
        $license_data = $this->db_manager->get_license_by_key($license);

        if (!$license_data || $license_data->status !== 'active') {
            return $this->send_error_response(
                'Invalid or inactive license',
                'INVALID_LICENSE',
                403
            );
        }

        if (!$this->db_manager->domains_match($license_data->domain, $domain)) {
            return $this->send_error_response(
                'Domain not authorized',
                'DOMAIN_MISMATCH',
                403
            );
        }

        // Get update information
        $update_info = get_option('sky_seo_boost_update_info', []);

        $response_data = [
            'authenticated' => true,
            'current_version' => $current_version,
            'latest_version' => $update_info['version'] ?? '0.0.0',
            'update_available' => version_compare($current_version, $update_info['version'] ?? '0', '<'),
        ];

        if ($response_data['update_available']) {
            $response_data['download_url'] = add_query_arg([
                'license' => $license,
                'domain' => $domain,
            ], SKY_LICENSE_MANAGER_PLUGIN_URL . 'download-handler.php');
            $response_data['info_url'] = $update_info['info_url'] ?? '';
            $response_data['tested'] = $update_info['tested'] ?? '';
            $response_data['requires'] = $update_info['requires'] ?? '';
            $response_data['requires_php'] = $update_info['requires_php'] ?? '';
            $response_data['changelog'] = $update_info['changelog'] ?? '';
        }

        // Sign the response
        $response_data = $this->sign_response($response_data);

        return new WP_REST_Response($response_data, 200);
    }

    /**
     * Health check endpoint
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response Response object
     */
    public function health_check($request) {
        global $wpdb;

        $table_name = $this->db_manager->get_table_name();
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;

        // Check signature generator availability
        $signature_available = class_exists('Sky_License_Signature_Generator') &&
                               Sky_License_Signature_Generator::is_available();

        $response_data = [
            'status' => 'healthy',
            'timestamp' => time(),
            'server_time' => current_time('mysql'),
            'database' => $table_exists ? 'connected' : 'error',
            'signature_enabled' => $signature_available,
            'version' => defined('SKY_LICENSE_MANAGER_VERSION') ? SKY_LICENSE_MANAGER_VERSION : 'unknown',
        ];

        // Sign the response
        $response_data = $this->sign_response($response_data);

        return new WP_REST_Response($response_data, 200);
    }

    /**
     * Sign response data using signature generator
     *
     * @param array $data Response data
     * @return array Signed response data
     */
    private function sign_response($data) {
        // Always add timestamp
        $data['timestamp'] = time();

        // Load signature generator if not already loaded
        if (!class_exists('Sky_License_Signature_Generator')) {
            $signature_path = SKY_LICENSE_MANAGER_INCLUDES_DIR . 'class-signature-generator.php';
            if (file_exists($signature_path)) {
                require_once($signature_path);
            }
        }

        // Sign if available
        if (class_exists('Sky_License_Signature_Generator') && Sky_License_Signature_Generator::is_available()) {
            $data = Sky_License_Signature_Generator::sign_response($data);
        }

        return $data;
    }

    /**
     * Send error response with consistent format
     *
     * @param string $message Error message
     * @param string $code Error code
     * @param int $status HTTP status code
     * @param array $debug_info Optional debug information
     * @return WP_REST_Response Error response
     */
    private function send_error_response($message, $code, $status = 403, $debug_info = []) {
        $response_data = [
            'authenticated' => false,
            'error' => $message,
            'error_code' => $code,
        ];

        // Add debug info in debug mode
        if (defined('WP_DEBUG') && WP_DEBUG && !empty($debug_info)) {
            $response_data['debug_info'] = $debug_info;
        }

        // Sign the error response too
        $response_data = $this->sign_response($response_data);

        return new WP_REST_Response($response_data, $status);
    }
}
