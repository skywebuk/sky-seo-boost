<?php
/**
 * Sky SEO License Manager - Core Plugin Class
 * Main orchestrator class that ties everything together
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Sky_SEO_License_Manager_Plugin {
    
    private static $instance = null;
    private $db_manager;
    private $api_handler;
    private $ajax_handler;
    private $admin_pages;
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Initialize components
        $this->db_manager = new Sky_License_Database_Manager();
        $this->api_handler = new Sky_License_API_Handler($this->db_manager);
        $this->ajax_handler = new Sky_License_AJAX_Handlers($this->db_manager);
        $this->admin_pages = new Sky_License_Admin_Pages($this->db_manager);
        
        $this->init_hooks();
    }
    
    /**
     * Initialize all hooks
     */
    private function init_hooks() {
        // Admin hooks
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('admin_init', [$this->db_manager, 'check_and_create_tables']);
        
        // API endpoint handlers
        add_action('init', [$this->api_handler, 'handle_api_endpoint']);
        
        // AJAX handlers - delegate to AJAX handler class
        $this->ajax_handler->register_ajax_handlers();
        
        // Create upload directory
        add_action('init', [$this->db_manager, 'create_upload_directory']);
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            'License Manager',
            'License Manager',
            'manage_options',
            'sky-license-manager',
            [$this->admin_pages, 'render_admin_page'],
            'dashicons-admin-network',
            30
        );
        
        add_submenu_page(
            'sky-license-manager',
            'Update Settings',
            'Update Settings',
            'manage_options',
            'sky-license-updates',
            [$this->admin_pages, 'render_updates_page']
        );
        
        add_submenu_page(
            'sky-license-manager',
            'API Info',
            'API Info',
            'manage_options',
            'sky-license-api-info',
            [$this->admin_pages, 'render_api_info_page']
        );
    }
    
    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'sky-license') === false) {
            return;
        }
        
        wp_enqueue_script(
            'sky-license-manager', 
            SKY_LICENSE_MANAGER_PLUGIN_URL . 'assets/admin.js', 
            ['jquery'], 
            SKY_LICENSE_MANAGER_VERSION, 
            true
        );
        
        wp_enqueue_style(
            'sky-license-manager', 
            SKY_LICENSE_MANAGER_PLUGIN_URL . 'assets/admin.css', 
            [], 
            SKY_LICENSE_MANAGER_VERSION
        );
        
        wp_localize_script('sky-license-manager', 'skyLicenseManager', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('sky_license_manager_nonce'),
            'api_url' => SKY_LICENSE_MANAGER_PLUGIN_URL . 'api-endpoint.php'
        ]);
    }
    
    /**
     * Get database manager instance
     */
    public function get_db_manager() {
        return $this->db_manager;
    }
    
    /**
     * Get API handler instance
     */
    public function get_api_handler() {
        return $this->api_handler;
    }
}