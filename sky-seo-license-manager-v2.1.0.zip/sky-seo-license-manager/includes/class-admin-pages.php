<?php
/**
 * Sky SEO License Manager - Admin Pages
 * Handles all admin page rendering
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Sky_License_Admin_Pages {
    
    private $db_manager;
    
    public function __construct($db_manager) {
        $this->db_manager = $db_manager;
    }
    
    /**
     * Render main admin page
     */
    public function render_admin_page() {
        $licenses = $this->db_manager->get_all_licenses();
        $stats = $this->db_manager->get_stats();
        ?>
        <div class="wrap">
            <h1>Sky SEO License Manager</h1>
            
            <div class="sky-license-stats">
                <div class="stat-box">
                    <h3>Total Licenses</h3>
                    <p><?php echo count($licenses); ?></p>
                </div>
                <div class="stat-box">
                    <h3>Active Licenses</h3>
                    <p><?php echo $stats['active']; ?></p>
                </div>
                <div class="stat-box">
                    <h3>Expired Licenses</h3>
                    <p><?php echo $stats['expired']; ?></p>
                </div>
                <div class="stat-box">
                    <h3>API Endpoint</h3>
                    <p><code><?php echo SKY_LICENSE_MANAGER_PLUGIN_URL . 'api-endpoint.php'; ?></code></p>
                </div>
            </div>
            
            <div class="sky-license-form">
                <h2>Add New License</h2>
                <form id="sky-license-form">
                    <table class="form-table">
                        <tr>
                            <th><label for="license_key">License Key</label></th>
                            <td>
                                <input type="text" id="license_key" name="license_key" class="regular-text" required />
                                <button type="button" class="button" onclick="generateLicenseKey()">Generate Key</button>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="domain">Domain</label></th>
                            <td>
                                <input type="text" id="domain" name="domain" class="regular-text" required />
                                <p class="description">Enter domain without http:// or www. Use * for any domain.</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="status">Status</label></th>
                            <td>
                                <select id="status" name="status">
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                    <option value="expired">Expired</option>
                                    <option value="suspended">Suspended</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="expires_at">Expires At</label></th>
                            <td>
                                <input type="datetime-local" id="expires_at" name="expires_at" />
                                <p class="description">Leave empty for no expiration</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="max_activations">Max Activations</label></th>
                            <td>
                                <input type="number" id="max_activations" name="max_activations" value="1" min="1" />
                            </td>
                        </tr>
                        <tr>
                            <th><label for="notes">Notes</label></th>
                            <td>
                                <textarea id="notes" name="notes" rows="3" cols="50"></textarea>
                            </td>
                        </tr>
                    </table>
                    <input type="hidden" id="license_id" name="license_id" value="" />
                    <p class="submit">
                        <button type="submit" class="button button-primary">Save License</button>
                        <button type="button" class="button" onclick="resetForm()">Cancel</button>
                    </p>
                </form>
            </div>
            
            <div class="sky-license-list">
                <h2>Existing Licenses</h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>License Key</th>
                            <th>Domain</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Expires</th>
                            <th>Last Check</th>
                            <th>Activations</th>
                            <th>Notes</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($licenses as $license) : ?>
                        <tr data-id="<?php echo $license->id; ?>">
                            <td><?php echo $license->id; ?></td>
                            <td><code><?php echo esc_html($license->license_key); ?></code></td>
                            <td><?php echo esc_html($license->domain); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo $license->status; ?>">
                                    <?php echo ucfirst($license->status); ?>
                                </span>
                            </td>
                            <td><?php echo date('Y-m-d', strtotime($license->created_at)); ?></td>
                            <td><?php 
                                if ($license->expires_at && $license->expires_at !== '0000-00-00 00:00:00') {
                                    echo date('Y-m-d', strtotime($license->expires_at));
                                } else {
                                    echo 'Never';
                                }
                            ?></td>
                            <td><?php echo $license->last_check ? human_time_diff(strtotime($license->last_check)) . ' ago' : 'Never'; ?></td>
                            <td><?php echo $license->activation_count . '/' . $license->max_activations; ?></td>
                            <td><?php echo esc_html(substr($license->notes, 0, 50)); ?></td>
                            <td>
                                <button class="button button-small" onclick="editLicense(<?php echo $license->id; ?>)">Edit</button>
                                <button class="button button-small" onclick="toggleLicense(<?php echo $license->id; ?>)">Toggle</button>
                                <button class="button button-small button-link-delete" onclick="deleteLicense(<?php echo $license->id; ?>)">Delete</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render updates page
     */
    public function render_updates_page() {
        $update_info = get_option('sky_seo_boost_update_info', [
            'version' => '2.0.0',
            'download_url' => '',
            'info_url' => 'https://skywebdesign.co.uk/plugins/sky-seo-boost',
            'tested' => '6.5',
            'requires' => '5.8',
            'requires_php' => '7.4',
            'changelog' => ''
        ]);
        
        $plugin_file_path = get_option('sky_seo_boost_file_path', '');
        
        ?>
        <div class="wrap">
            <h1>Sky SEO Boost Update Settings</h1>
            
            <div class="sky-license-form">
                <h2>Plugin Update Information</h2>
                <form id="update-info-form">
                    <table class="form-table">
                        <tr>
                            <th><label for="version">Current Version</label></th>
                            <td>
                                <input type="text" id="version" name="version" value="<?php echo esc_attr($update_info['version']); ?>" class="regular-text" required />
                                <p class="description">The latest version number of Sky SEO Boost</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="tested">Tested Up To</label></th>
                            <td>
                                <input type="text" id="tested" name="tested" value="<?php echo esc_attr($update_info['tested']); ?>" class="regular-text" />
                                <p class="description">WordPress version tested up to (e.g., 6.5)</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="requires">Requires WordPress</label></th>
                            <td>
                                <input type="text" id="requires" name="requires" value="<?php echo esc_attr($update_info['requires']); ?>" class="regular-text" />
                                <p class="description">Minimum WordPress version required (e.g., 5.8)</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="requires_php">Requires PHP</label></th>
                            <td>
                                <input type="text" id="requires_php" name="requires_php" value="<?php echo esc_attr($update_info['requires_php']); ?>" class="regular-text" />
                                <p class="description">Minimum PHP version required (e.g., 7.4)</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="info_url">Info URL</label></th>
                            <td>
                                <input type="url" id="info_url" name="info_url" value="<?php echo esc_attr($update_info['info_url']); ?>" class="regular-text" />
                                <p class="description">URL for more information about the update</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="changelog">Changelog</label></th>
                            <td>
                                <textarea id="changelog" name="changelog" rows="10" cols="50"><?php echo esc_textarea($update_info['changelog']); ?></textarea>
                                <p class="description">Describe what's new in this version</p>
                            </td>
                        </tr>
                    </table>
                    <p class="submit">
                        <button type="submit" class="button button-primary">Save Update Info</button>
                    </p>
                </form>
            </div>
            
            <div class="sky-license-form">
                <h2>Plugin File Upload</h2>
                <form id="plugin-upload-form" enctype="multipart/form-data">
                    <table class="form-table">
                        <tr>
                            <th><label for="plugin_file">Plugin ZIP File</label></th>
                            <td>
                                <input type="file" id="plugin_file" name="plugin_file" accept=".zip" />
                                <p class="description">Upload the Sky SEO Boost plugin ZIP file</p>
                                <?php if ($plugin_file_path && file_exists($plugin_file_path)) : ?>
                                <p class="description" style="color: #00a32a;">
                                    ✓ Current file: <?php echo basename($plugin_file_path); ?> 
                                    (<?php echo size_format(filesize($plugin_file_path)); ?>)
                                </p>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                    <p class="submit">
                        <button type="submit" class="button button-primary">Upload Plugin File</button>
                    </p>
                </form>
            </div>
            
            <div class="sky-license-form">
                <h2>Update Endpoints</h2>
                <p>Clients should check for updates at:</p>
                <p><code style="font-size: 14px; background: #f0f0f0; padding: 10px; display: block;">
                    <?php echo SKY_LICENSE_MANAGER_PLUGIN_URL; ?>update-handler.php
                </code></p>
                
                <p>Downloads will be served from:</p>
                <p><code style="font-size: 14px; background: #f0f0f0; padding: 10px; display: block;">
                    <?php echo SKY_LICENSE_MANAGER_PLUGIN_URL; ?>download-handler.php
                </code></p>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Update info form
            $('#update-info-form').on('submit', function(e) {
                e.preventDefault();
                
                const formData = {
                    action: 'sky_license_save_update_info',
                    nonce: '<?php echo wp_create_nonce('sky_license_manager_nonce'); ?>',
                    version: $('#version').val(),
                    tested: $('#tested').val(),
                    requires: $('#requires').val(),
                    requires_php: $('#requires_php').val(),
                    info_url: $('#info_url').val(),
                    changelog: $('#changelog').val()
                };
                
                $.post(ajaxurl, formData, function(response) {
                    if (response.success) {
                        alert('Update information saved successfully');
                    } else {
                        alert('Error: ' + response.data.message);
                    }
                });
            });
            
            // Plugin upload form
            $('#plugin-upload-form').on('submit', function(e) {
                e.preventDefault();
                
                const fileInput = $('#plugin_file')[0];
                if (!fileInput.files.length) {
                    alert('Please select a file to upload');
                    return;
                }
                
                const formData = new FormData();
                formData.append('action', 'sky_license_upload_plugin');
                formData.append('nonce', '<?php echo wp_create_nonce('sky_license_manager_nonce'); ?>');
                formData.append('plugin_file', fileInput.files[0]);
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            alert('Plugin file uploaded successfully');
                            location.reload();
                        } else {
                            alert('Error: ' + response.data.message);
                        }
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    /**
     * Render API info page
     */
    public function render_api_info_page() {
        $endpoint_url = SKY_LICENSE_MANAGER_PLUGIN_URL . 'api-endpoint.php';
        $update_url = SKY_LICENSE_MANAGER_PLUGIN_URL . 'update-handler.php';
        $alt_endpoint = home_url('/sky-seo-licenses/licenses.php');
        ?>
        <div class="wrap">
            <h1>Sky SEO License API Information</h1>
            
            <div style="background: #fff; padding: 20px; border: 1px solid #ccd0d4; margin: 20px 0;">
                <h2>API Endpoints</h2>
                
                <h3>License Validation Endpoint:</h3>
                <p><code style="font-size: 14px; background: #f0f0f0; padding: 10px; display: block;">
                    <?php echo esc_html($endpoint_url); ?>
                </code></p>
                
                <h3>Update Check Endpoint:</h3>
                <p><code style="font-size: 14px; background: #f0f0f0; padding: 10px; display: block;">
                    <?php echo esc_html($update_url); ?>
                </code></p>
                
                <h3>Legacy Endpoint (Backward Compatibility):</h3>
                <p><code style="font-size: 14px; background: #f0f0f0; padding: 10px; display: block;">
                    <?php echo esc_html($alt_endpoint); ?>
                </code></p>
                
                <h2>Integration Instructions</h2>
                <h3>For Sky SEO Boost Plugin</h3>
                <p>Update the following constants in your plugin's license manager:</p>
                
                <pre style="background: #f0f0f0; padding: 15px; overflow-x: auto;">
// License validation
const LICENSE_SERVER_URL = '<?php echo esc_html($endpoint_url); ?>';

// Update checking
const UPDATE_SERVER_URL = '<?php echo esc_html($update_url); ?>';</pre>
                
                <h3>Required Parameters</h3>
                <p><strong>For License Validation:</strong></p>
                <ul>
                    <li><code>license</code> - The license key</li>
                    <li><code>domain</code> - The domain making the request</li>
                </ul>
                
                <p><strong>For Update Checking:</strong></p>
                <ul>
                    <li><code>license</code> - The license key</li>
                    <li><code>domain</code> - The domain making the request</li>
                    <li><code>version</code> - Current plugin version</li>
                    <li><code>slug</code> - Plugin slug (optional, defaults to 'sky-seo-boost')</li>
                </ul>
                
                <h2>Test the Endpoints</h2>
                <p>
                    <a href="<?php echo esc_url($endpoint_url); ?>" target="_blank" class="button button-primary">Test License Endpoint</a>
                    <a href="<?php echo esc_url($update_url); ?>" target="_blank" class="button button-primary">Test Update Endpoint</a>
                </p>
            </div>
        </div>
        <?php
    }
}