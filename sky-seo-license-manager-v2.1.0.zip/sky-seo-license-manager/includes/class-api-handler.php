<?php
/**
 * Sky SEO License Manager - API Handler
 * Handles all API endpoint operations
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Sky_License_API_Handler {
    
    private $db_manager;
    
    public function __construct($db_manager) {
        $this->db_manager = $db_manager;
    }
    
    /**
     * Handle API endpoint requests
     */
    public function handle_api_endpoint() {
        $request_uri = $_SERVER['REQUEST_URI'];
        $plugin_url_path = parse_url(SKY_LICENSE_MANAGER_PLUGIN_URL, PHP_URL_PATH);
        
        // Check for various endpoint paths
        $is_api_request = false;
        
        // Check main API endpoint
        if (strpos($request_uri, $plugin_url_path . 'api-endpoint.php') !== false) {
            $is_api_request = true;
        }
        
        // Check legacy endpoint in subfolder
        if (strpos($request_uri, $plugin_url_path . 'sky-seo-licenses/licenses.php') !== false) {
            $is_api_request = true;
        }
        
        // Check alternative legacy path
        if (strpos($request_uri, '/sky-seo-licenses/licenses.php') !== false) {
            $is_api_request = true;
        }
        
        if ($is_api_request) {
            $this->process_license_validation();
        }
    }
    
    /**
     * Check if required tables exist
     */
    private function check_tables_exist() {
        global $wpdb;
        
        $table_name = $this->db_manager->get_table_name();
        
        $tables_exist = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;
        
        if (!$tables_exist) {
            // Try to create tables
            $this->db_manager->create_database_tables();
            
            // Check again
            $tables_exist = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;
        }
        
        return $tables_exist;
    }
    
    /**
     * Process license validation
     */
    public function process_license_validation() {
        // Prevent any output before headers
        if (ob_get_level()) {
            ob_clean();
        }
        
        // Set headers
        header('Content-Type: application/json; charset=utf-8');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        // Handle preflight requests
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(200);
            exit(0);
        }
        
        // Check if tables exist before proceeding
        if (!$this->check_tables_exist()) {
            $this->send_json_response([
                'authenticated' => false,
                'error' => 'License system not properly configured',
                'error_code' => 'SYSTEM_ERROR'
            ], 500);
        }
        
        // Get POST data - try multiple methods to capture data
        $post_data = $this->get_request_data();
        
        // Extract license and domain
        $license = isset($post_data['license']) ? sanitize_text_field($post_data['license']) : '';
        $domain = isset($post_data['domain']) ? sanitize_text_field($post_data['domain']) : '';
        
        // Try to get domain from other sources if not provided
        if (empty($domain) || $domain === 'UNKNOWN') {
            // Try from site_url
            if (!empty($post_data['site_url'])) {
                $domain = $this->db_manager->get_domain_from_url($post_data['site_url']);
            }
            // Try from referer
            elseif (!empty($_SERVER['HTTP_REFERER'])) {
                $domain = $this->db_manager->get_domain_from_url($_SERVER['HTTP_REFERER']);
            }
            // Try from host header
            elseif (!empty($_SERVER['HTTP_HOST'])) {
                $domain = $this->db_manager->normalize_domain($_SERVER['HTTP_HOST']);
            }
        }
        
        // Validate required parameters
        if (empty($license)) {
            $this->send_json_response([
                'authenticated' => false,
                'error' => 'Missing license key',
                'required_params' => ['license', 'domain']
            ], 400);
        }
        
        if (empty($domain) || $domain === 'UNKNOWN') {
            $this->send_json_response([
                'authenticated' => false,
                'error' => 'Missing or invalid domain',
                'required_params' => ['license', 'domain']
            ], 400);
        }
        
        // Validate license
        $result = $this->validate_license($license, $domain);
        
        // Send response with appropriate status code
        $status_code = $result['authenticated'] ? 200 : 403;
        $this->send_json_response($result, $status_code);
    }
    
    /**
     * Get request data from multiple sources
     */
    private function get_request_data() {
        $post_data = [];
        
        // Try to get raw input first
        $input = file_get_contents('php://input');
        
        // Try to decode JSON input
        if (!empty($input)) {
            $json_data = json_decode($input, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($json_data)) {
                $post_data = $json_data;
            }
        }
        
        // Fall back to $_POST if no JSON data
        if (empty($post_data)) {
            $post_data = $_POST;
        }
        
        // Also merge $_REQUEST for compatibility
        if (!empty($_REQUEST)) {
            $post_data = array_merge($post_data, $_REQUEST);
        }
        
        // Try to parse form-encoded data from raw input
        if (empty($post_data) && !empty($input)) {
            parse_str($input, $parsed_data);
            if (!empty($parsed_data)) {
                $post_data = $parsed_data;
            }
        }
        
        return $post_data;
    }
    
    /**
     * Send JSON response with proper headers and exit
     */
    private function send_json_response($data, $status_code = 200) {
        http_response_code($status_code);
        
        // Add timestamp to response
        $data['timestamp'] = current_time('timestamp');
        
        // Ensure we have clean output
        if (ob_get_level()) {
            ob_clean();
        }
        
        // Send the JSON response
        echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        exit;
    }
    
    /**
     * Validate a license
     */
    public function validate_license($license, $domain) {
        global $wpdb;
        
        $table_name = $this->db_manager->get_table_name();
        
        // Normalize domain
        $domain = $this->db_manager->normalize_domain($domain);
        
        // Double-check if table exists (defensive programming)
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            // Try to create tables one more time
            $this->db_manager->create_database_tables();
            
            // If still doesn't exist, return error
            if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
                return [
                    'authenticated' => false,
                    'error' => 'License system not properly configured',
                    'error_code' => 'SYSTEM_ERROR'
                ];
            }
        }
        
        // Look up license
        $license_data = $this->db_manager->get_license_by_key($license);
        
        if (!$license_data) {
            return [
                'authenticated' => false,
                'error' => 'Invalid license key',
                'error_code' => 'INVALID_LICENSE'
            ];
        }
        
        // Check status
        if ($license_data->status !== 'active') {
            return [
                'authenticated' => false,
                'error' => 'License is ' . $license_data->status,
                'error_code' => 'LICENSE_' . strtoupper($license_data->status),
                'status' => $license_data->status
            ];
        }
        
        // Check expiration
        if (!empty($license_data->expires_at) && $license_data->expires_at !== '0000-00-00 00:00:00') {
            $expiry_time = strtotime($license_data->expires_at);
            if ($expiry_time < time()) {
                return [
                    'authenticated' => false,
                    'error' => 'License has expired',
                    'error_code' => 'LICENSE_EXPIRED',
                    'expired_at' => $license_data->expires_at
                ];
            }
        }
        
        // Check domain
        $license_domain = $this->db_manager->normalize_domain($license_data->domain);
        if ($license_domain !== $domain && $license_domain !== '*') {
            return [
                'authenticated' => false,
                'error' => 'Domain mismatch',
                'error_code' => 'DOMAIN_MISMATCH',
                'debug_info' => [
                    'license_domain' => $license_domain,
                    'request_domain' => $domain
                ]
            ];
        }
        
        // Check activation limits
        if ($license_data->activation_count >= $license_data->max_activations) {
            return [
                'authenticated' => false,
                'error' => 'Maximum activations reached',
                'error_code' => 'MAX_ACTIVATIONS',
                'activation_count' => $license_data->activation_count,
                'max_activations' => $license_data->max_activations
            ];
        }
        
        // Success!
        // Update last check time
        $this->db_manager->update_last_check($license_data->id);
        
        // Prepare successful response
        $response = [
            'authenticated' => true,
            'domain' => $domain,
            'status' => 'active',
            'license_key' => substr($license, 0, 4) . '****' . substr($license, -4), // Masked license key
        ];
        
        // Add expiration info if applicable
        if (!empty($license_data->expires_at) && $license_data->expires_at !== '0000-00-00 00:00:00') {
            $response['expires_at'] = $license_data->expires_at;
            $response['expires_in_days'] = max(0, floor((strtotime($license_data->expires_at) - time()) / 86400));
        }
        
        // Add activation info
        $response['activations'] = [
            'used' => $license_data->activation_count,
            'limit' => $license_data->max_activations,
            'remaining' => max(0, $license_data->max_activations - $license_data->activation_count)
        ];
        
        return $response;
    }
    
    /**
     * Handle public AJAX license validation
     */
    public function handle_license_validation() {
        // Get request data
        $post_data = $this->get_request_data();
        
        // Check nonce for AJAX requests
        if (defined('DOING_AJAX') && DOING_AJAX && !wp_verify_nonce($post_data['nonce'] ?? '', 'sky_license_validation')) {
            wp_send_json_error([
                'authenticated' => false,
                'error' => 'Security check failed',
                'error_code' => 'INVALID_NONCE'
            ], 403);
        }
        
        $license = isset($post_data['license']) ? sanitize_text_field($post_data['license']) : '';
        $domain = isset($post_data['domain']) ? sanitize_text_field($post_data['domain']) : '';
        
        // Try to get domain from site_url if domain is empty
        if (empty($domain) && !empty($post_data['site_url'])) {
            $domain = $this->db_manager->get_domain_from_url($post_data['site_url']);
        }
        
        if (empty($license) || empty($domain)) {
            wp_send_json_error([
                'authenticated' => false,
                'error' => 'Missing license key or domain',
                'error_code' => 'MISSING_PARAMS'
            ], 400);
        }
        
        $result = $this->validate_license($license, $domain);
        
        if ($result['authenticated']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result, 403);
        }
    }
    
    /**
     * Process update check request
     */
    public function process_update_check() {
        // Get request data
        $post_data = $this->get_request_data();
        
        $license = isset($post_data['license']) ? sanitize_text_field($post_data['license']) : '';
        $domain = isset($post_data['domain']) ? sanitize_text_field($post_data['domain']) : '';
        $current_version = isset($post_data['version']) ? sanitize_text_field($post_data['version']) : '';
        
        // Try to get domain from site_url if domain is empty
        if (empty($domain) && !empty($post_data['site_url'])) {
            $domain = $this->db_manager->get_domain_from_url($post_data['site_url']);
        }
        
        // First validate the license
        $validation = $this->validate_license($license, $domain);
        
        if (!$validation['authenticated']) {
            return [
                'success' => false,
                'error' => $validation['error'],
                'error_code' => $validation['error_code'] ?? 'VALIDATION_FAILED'
            ];
        }
        
        // Get update information
        $update_info = get_option('sky_seo_boost_update_info', []);
        
        // Check if update is available
        if (version_compare($current_version, $update_info['version'] ?? '0', '<')) {
            return [
                'success' => true,
                'update_available' => true,
                'version' => $update_info['version'],
                'download_url' => add_query_arg([
                    'license' => $license,
                    'domain' => $domain
                ], SKY_LICENSE_MANAGER_PLUGIN_URL . 'download-handler.php'),
                'info_url' => $update_info['info_url'] ?? '',
                'tested' => $update_info['tested'] ?? '',
                'requires' => $update_info['requires'] ?? '',
                'requires_php' => $update_info['requires_php'] ?? '',
                'changelog' => $update_info['changelog'] ?? ''
            ];
        }
        
        return [
            'success' => true,
            'update_available' => false,
            'message' => 'You have the latest version'
        ];
    }
}