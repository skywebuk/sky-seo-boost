<?php
/**
 * License Response Signature Generator
 * 
 * Server-side counterpart to Sky_SEO_License_Signature_Validator
 * Signs license responses to prevent tampering and man-in-the-middle attacks
 * 
 * @package Sky_SEO_License_Manager
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Signature Generator Class
 * 
 * SECURITY CRITICAL: This class contains the PRIVATE KEY
 * - Private key must NEVER be distributed with the client plugin
 * - Store private key outside web root if possible
 * - Use environment variables in production environments
 * - Rotate keys periodically for enhanced security
 */
class Sky_License_Signature_Generator {
    
    /**
     * FALLBACK Private RSA key for signing responses
     *
     * SECURITY BEST PRACTICES:
     *
     * RECOMMENDED: Use environment variable or wp-config.php constant instead
     * This hardcoded key is a FALLBACK ONLY for compatibility.
     *
     * SETUP OPTIONS (in order of security):
     *
     * 1. ENVIRONMENT VARIABLE (Most Secure):
     *    Set in your hosting control panel or .env file:
     *    SKY_LICENSE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nMIIE..."
     *
     * 2. WP-CONFIG.PHP (Recommended):
     *    Add to wp-config.php (above "That's all, stop editing"):
     *    define('SKY_LICENSE_PRIVATE_KEY', '-----BEGIN PRIVATE KEY-----
     *    MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSk...
     *    -----END PRIVATE KEY-----');
     *
     * 3. EXTERNAL FILE (Very Secure):
     *    Store in /home/youruser/keys/license-private.pem (outside web root)
     *    Set constant: define('SKY_LICENSE_PRIVATE_KEY_FILE', '/home/youruser/keys/license-private.pem');
     *
     * TO GENERATE NEW KEY PAIR:
     *
     * Step 1: Generate private key (2048-bit RSA)
     * openssl genrsa -out license_private_key.pem 2048
     *
     * Step 2: Generate public key from private key
     * openssl rsa -in license_private_key.pem -pubout -out license_public_key.pem
     *
     * Step 3: Store private key using one of the methods above
     *
     * Step 4: Copy contents of license_public_key.pem to plugin's
     *         Sky_SEO_License_Signature_Validator::PUBLIC_KEY constant
     *
     * IMPORTANT: Both keys must match (generated together)
     *
     * WARNING: This hardcoded fallback key should be removed in production
     */
    const PRIVATE_KEY_FALLBACK = <<<EOD
-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDmEZ5VrxeGolOC
VqnqqbPJIOxr6JVCM46CAK2yqhx/9W16u6iYmCQfYg0v0vJk2cKqYs+auonyUL5j
a6snXHxwgT4PFrXN+rDEnCeEX6KbPG3MVzLrN/+JJvOhv0kBw+gkG4fTACzkPMTa
eGl3sd8xQJxWkZLH9JYjAbjaBSdDwy+kWJMlXqwkab6ALxPHxQwzQ1QfDZX2uCjI
6+mhWeL9mboCr3sDh1ASq/B13RaWEYumersDtVgukGJTasAmjLYOueBvwHkKRCkV
nQAUptI1D8Hi3GwH5011CMuTzNzVPyOr+L8WqV8/kVZ7JPaAdnFjkUXzq1xYWQuH
UDQH+pClAgMBAAECggEAVg0z9CdzvLM9WexRTIihyrIqS6goH6VKAZ0AWumelEu3
YacMBdst86EIfqE/cXIziehAb0ajLwN9WpFcaHICx0/H5vvfD0ZbVIZ1j2D34GlH
Rh09WdZNmT589LwnseXVD6BOeqC/qbSDCpXsGM1qRjE86HI1fN2iRECyI7W2vHRw
5n1c3RwmkGUc1uDTaFNNMjg7dVkT8uPR0rrE2MTCSi6sqYFBKZyB6n7EX83b4h3g
8hnjk6mda//CshvkfGLbi0rTJXTbOfffhN1w2MrZjUg23qrAD1t65YaXo5rBf0oI
G9wDCqy8ohvWFPCRBYCYo01BLRQiGkXCTz6Y7TgK9wKBgQD4aRWpu+e/8m7VCz/a
NS4vqpNQdlwuNxzi+FlkXiIl4FLchoZ2oWQ0LwV+h6jecdWYdtNcJZZJC5L7AMJv
0Xg/lvPHbr1RiVl4/i7BR92OCD4p3bJusvt/Hh5XsQ6K3/GtU86MJ7TIlPHWaFp3
SDs8iRXA47or064ICUcf3omMIwKBgQDtGROZLHaIzsjTs+caGrRWpBD7UvdFK3yU
8h3L2c8RDkphjwsQH5f5Hfney1s2xLlorBYeUJ5IZeUsG9Z789s8zTr5JIVNGkEu
q9syTTsJLXFL6yR1ESriDUXFLqjQy787NACfsmZ1KjVOqAjR4WQeNRvAcP86p5/W
jEwYCH34lwKBgQCQztFuDLfgUTcCwngKgA3Yg5s0wIqj9kTEmvmhZK6LXeVv4Ivq
A9MiCHcvd22dnsZhBoPXp6GgGzsnTx4JiRaMGzco/wklyud5fNNMoNQqw+tZBH/L
wFKTm78cZ36OvlVoMP6q/UqJ0ynXTyXNezHs7AzeUOJqQg+lZ6MqlNOh+QKBgFHy
N9baCkHwjnK1HCvmjOvhGslyfGoYxJ9KK0g4iJvRf53GbcFt2f3NAX6idG0ygw6N
Y7uoi3xkU1fyayg+OUkDed2AZN4oM90oosL49G2QmjbuF5SqkVK92Z50KP65XOfe
alTHuSfHpdMAusOnjg3utx/FLkGci98AcJBh5wATAoGBAII9FMnOIICG4ujW7556
0jODbsREPrz4yTM7cjESTW0VSAj+V/PYKvT/6U+yoSn2d8HnOcWgq8UoZsJbvKyd
uklkhK0YEkxy68OMw22z/ZODDi4TYHkfAtRrpjYaI13bSmYfE5LEZjvc9xDNzlSo
t37RJJgmUrJaTABwIoMw/cow
-----END PRIVATE KEY-----
EOD;

    /**
     * Get the private key from secure storage
     *
     * Checks multiple sources in order of security preference:
     * 1. Environment variable: SKY_LICENSE_PRIVATE_KEY
     * 2. WordPress constant: SKY_LICENSE_PRIVATE_KEY (from wp-config.php)
     * 3. External file: SKY_LICENSE_PRIVATE_KEY_FILE constant
     * 4. Fallback: Hardcoded constant (least secure)
     *
     * @return string Private key in PEM format
     */
    private static function get_private_key() {
        // 1. Try environment variable (most secure)
        $env_key = getenv('SKY_LICENSE_PRIVATE_KEY');
        if (!empty($env_key)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('License Signature: Using private key from environment variable');
            }
            return $env_key;
        }

        // 2. Try WordPress constant (recommended for WordPress)
        if (defined('SKY_LICENSE_PRIVATE_KEY')) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('License Signature: Using private key from wp-config.php constant');
            }
            return SKY_LICENSE_PRIVATE_KEY;
        }

        // 3. Try external file (very secure)
        if (defined('SKY_LICENSE_PRIVATE_KEY_FILE')) {
            $key_file = SKY_LICENSE_PRIVATE_KEY_FILE;
            if (file_exists($key_file) && is_readable($key_file)) {
                $key_content = file_get_contents($key_file);
                if (!empty($key_content)) {
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        error_log('License Signature: Using private key from external file: ' . $key_file);
                    }
                    return $key_content;
                }
            } else {
                error_log('License Signature: External key file not found or not readable: ' . $key_file);
            }
        }

        // 4. Fallback to hardcoded constant (least secure, but maintains compatibility)
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('License Signature: WARNING - Using hardcoded fallback private key (not recommended for production)');
        }
        return self::PRIVATE_KEY_FALLBACK;
    }

    /**
     * Maximum allowed timestamp skew (in seconds)
     * Accounts for clock differences between servers
     */
    const MAX_CLOCK_SKEW = 30;
    
    /**
     * Sign license response data
     * 
     * Main method to sign any response before sending to client.
     * Adds timestamp and cryptographic signature to prevent tampering.
     * 
     * @param array $data Response data to sign (must be array)
     * @return array Data with 'signature' and 'timestamp' fields added
     */
    public static function sign_response($data) {
        // Validate input
        if (!is_array($data)) {
            error_log('License Server: Cannot sign non-array data');
            return $data;
        }
        
        // Check if OpenSSL is available
        if (!self::is_available()) {
            error_log('License Server: OpenSSL not available - cannot sign response');
            // Return unsigned data with warning
            $data['signature_error'] = 'OpenSSL not available on server';
            return $data;
        }
        
        // Add timestamp (Unix timestamp)
        // This prevents replay attacks
        $data['timestamp'] = time();
        
        // Create canonical JSON representation
        // Must match exactly with client-side validator
        $canonical_json = self::create_canonical_json($data);
        
        if (empty($canonical_json)) {
            error_log('License Server: Failed to create canonical JSON');
            return $data;
        }
        
        // Load private key from secure storage
        $private_key = openssl_pkey_get_private(self::get_private_key());
        
        if ($private_key === false) {
            $error = openssl_error_string();
            error_log('License Server: Failed to load private key - ' . $error);
            $data['signature_error'] = 'Private key error';
            return $data;
        }
        
        // Sign the canonical JSON using SHA256
        $signature_binary = '';
        $result = openssl_sign(
            $canonical_json,
            $signature_binary,
            $private_key,
            OPENSSL_ALGO_SHA256
        );
        
        // Free key resource
        openssl_free_key($private_key);
        
        // Check signing result
        if ($result === false) {
            $error = openssl_error_string();
            error_log('License Server: Failed to sign response - ' . $error);
            $data['signature_error'] = 'Signing failed';
            return $data;
        }
        
        // Encode signature as base64 for JSON transmission
        $data['signature'] = base64_encode($signature_binary);
        
        // Log success in debug mode
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('License Server: Response signed successfully');
        }
        
        return $data;
    }
    
    /**
     * Create canonical JSON representation for signing
     * 
     * CRITICAL: This must produce EXACTLY the same output as the 
     * client-side Sky_SEO_License_Signature_Validator::create_canonical_json()
     * 
     * Any difference in formatting will cause signature verification to fail.
     * 
     * @param array $data Response data
     * @return string Canonical JSON string
     */
    private static function create_canonical_json($data) {
        // Remove signature field if present
        // (We're creating it, not signing it)
        if (isset($data['signature'])) {
            unset($data['signature']);
        }
        
        // Also remove any signature error messages
        if (isset($data['signature_error'])) {
            unset($data['signature_error']);
        }
        
        // Sort keys recursively for consistent ordering
        // This ensures the same data always produces the same JSON
        $data = self::sort_array_recursive($data);
        
        // Create JSON with consistent formatting
        // - JSON_UNESCAPED_SLASHES: Don't escape forward slashes
        // - JSON_UNESCAPED_UNICODE: Don't escape unicode characters
        // This must match the client-side encoding exactly
        $json = json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        
        if ($json === false) {
            error_log('License Server: Failed to create canonical JSON - ' . json_last_error_msg());
            return '';
        }
        
        return $json;
    }
    
    /**
     * Recursively sort array by keys
     * 
     * Ensures consistent key ordering for signature generation.
     * Must match client-side sorting exactly.
     * 
     * @param mixed $array Array to sort (or scalar value)
     * @return mixed Sorted array or original value if not array
     */
    private static function sort_array_recursive($array) {
        // If not an array, return as-is
        if (!is_array($array)) {
            return $array;
        }
        
        // Sort by keys alphabetically
        ksort($array);
        
        // Recursively sort nested arrays
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                $array[$key] = self::sort_array_recursive($value);
            }
        }
        
        return $array;
    }
    
    /**
     * Verify that signature can be validated
     * 
     * Useful for testing: signs data then verifies it can be validated.
     * Requires the public key to be available.
     * 
     * @param array $data Data to test
     * @return bool True if signature validates correctly
     */
    public static function test_signature($data) {
        // Sign the data
        $signed_data = self::sign_response($data);
        
        // Check if signing succeeded
        if (!isset($signed_data['signature'])) {
            error_log('License Server: Test failed - no signature generated');
            return false;
        }
        
        // Try to verify (requires public key)
        // In production, this would be done client-side
        // This is just for server-side testing
        
        // Extract public key from private key
        $private_key = openssl_pkey_get_private(self::get_private_key());
        if ($private_key === false) {
            return false;
        }
        
        $key_details = openssl_pkey_get_details($private_key);
        openssl_free_key($private_key);
        
        if (!isset($key_details['key'])) {
            return false;
        }
        
        $public_key_pem = $key_details['key'];
        $public_key = openssl_pkey_get_public($public_key_pem);
        
        if ($public_key === false) {
            return false;
        }
        
        // Create canonical JSON (without signature)
        $canonical = self::create_canonical_json($signed_data);
        
        // Decode signature
        $signature_binary = base64_decode($signed_data['signature'], true);
        
        // Verify
        $result = openssl_verify(
            $canonical,
            $signature_binary,
            $public_key,
            OPENSSL_ALGO_SHA256
        );
        
        openssl_free_key($public_key);
        
        return ($result === 1);
    }
    
    /**
     * Check if OpenSSL extension is available
     * 
     * @return bool True if OpenSSL functions are available
     */
    public static function is_available() {
        return function_exists('openssl_sign') &&
               function_exists('openssl_pkey_get_private') &&
               function_exists('openssl_free_key');
    }
    
    /**
     * Get public key from private key
     * 
     * Useful for initial setup - extracts the public key that
     * should be embedded in the client plugin.
     * 
     * @return string|false Public key in PEM format or false on error
     */
    public static function get_public_key() {
        if (!self::is_available()) {
            return false;
        }

        $private_key = openssl_pkey_get_private(self::get_private_key());
        
        if ($private_key === false) {
            error_log('License Server: Failed to load private key');
            return false;
        }
        
        $key_details = openssl_pkey_get_details($private_key);
        openssl_free_key($private_key);
        
        if (!isset($key_details['key'])) {
            error_log('License Server: Failed to extract public key');
            return false;
        }
        
        return $key_details['key'];
    }
    
    /**
     * Validate private key format
     * 
     * Checks if the private key can be loaded and used.
     * Useful for diagnostics.
     * 
     * @return bool True if private key is valid
     */
    public static function validate_private_key() {
        if (!self::is_available()) {
            return false;
        }

        $private_key = openssl_pkey_get_private(self::get_private_key());
        
        if ($private_key === false) {
            return false;
        }
        
        openssl_free_key($private_key);
        return true;
    }
    
    /**
     * Get detailed status information
     * 
     * Useful for admin diagnostics and debugging.
     * 
     * @return array Status information
     */
    public static function get_status() {
        $status = [
            'openssl_available' => self::is_available(),
            'private_key_valid' => false,
            'can_extract_public_key' => false,
            'functions' => [
                'openssl_sign' => function_exists('openssl_sign'),
                'openssl_pkey_get_private' => function_exists('openssl_pkey_get_private'),
                'openssl_free_key' => function_exists('openssl_free_key'),
            ],
        ];
        
        if (self::is_available()) {
            $status['private_key_valid'] = self::validate_private_key();
            $status['can_extract_public_key'] = (self::get_public_key() !== false);
        }
        
        if (defined('OPENSSL_VERSION_TEXT')) {
            $status['openssl_version'] = OPENSSL_VERSION_TEXT;
        }
        
        return $status;
    }
}