<?php
/**
 * Sky SEO License Manager - Database Manager
 * Handles all database operations
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Sky_License_Database_Manager {
    
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . SKY_LICENSE_MANAGER_TABLE;
    }
    
    /**
     * Get licenses table name
     */
    public function get_table_name() {
        return $this->table_name;
    }
    
    /**
     * Check and create tables if they don't exist
     */
    public function check_and_create_tables() {
        global $wpdb;
        
        $licenses_exist = $wpdb->get_var("SHOW TABLES LIKE '$this->table_name'") === $this->table_name;
        
        if (!$licenses_exist) {
            $this->create_database_tables();
        }
    }
    
    /**
     * Create database tables
     */
    public function create_database_tables() {
        global $wpdb;
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Licenses table
        $licenses_table = "CREATE TABLE IF NOT EXISTS $this->table_name (
            id int(11) NOT NULL AUTO_INCREMENT,
            license_key varchar(255) NOT NULL,
            domain varchar(255) NOT NULL,
            status varchar(20) DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            expires_at datetime DEFAULT NULL,
            last_check datetime DEFAULT NULL,
            activation_count int(11) DEFAULT 0,
            max_activations int(11) DEFAULT 1,
            notes text,
            PRIMARY KEY (id),
            UNIQUE KEY license_key (license_key),
            KEY domain (domain),
            KEY status (status)
        ) $charset_collate;";
        
        // Execute the query
        dbDelta($licenses_table);
        
        // Verify table was created
        $licenses_created = $wpdb->get_var("SHOW TABLES LIKE '$this->table_name'") === $this->table_name;
        
        if (!$licenses_created) {
            // Try direct query as fallback
            $wpdb->query($licenses_table);
        }
        
        update_option('sky_license_manager_db_version', SKY_LICENSE_MANAGER_DB_VERSION);
    }
    
    /**
     * Create upload directory for plugin files
     */
    public function create_upload_directory() {
        $upload_dir = wp_upload_dir();
        $license_dir = $upload_dir['basedir'] . '/sky-licenses';
        
        if (!file_exists($license_dir)) {
            wp_mkdir_p($license_dir);
            
            // Create .htaccess to protect directory
            $htaccess_content = "Order Deny,Allow\nDeny from all";
            file_put_contents($license_dir . '/.htaccess', $htaccess_content);
        }
    }
    
    /**
     * Create the endpoint files
     */
    public function create_endpoint_files() {
        // Create API endpoint file
        $endpoint_file = SKY_LICENSE_MANAGER_PLUGIN_DIR . 'api-endpoint.php';
        
        if (!file_exists($endpoint_file)) {
            $content = '<?php
/**
 * Sky SEO License API Endpoint
 * This file handles license validation requests
 */

// Load WordPress
$wp_load_path = dirname(dirname(dirname(dirname(__FILE__)))) . \'/wp-load.php\';
if (file_exists($wp_load_path)) {
    require_once($wp_load_path);
} else {
    // Try alternative path
    require_once(\'../../../../wp-load.php\');
}

// Handle the request
if (class_exists(\'Sky_SEO_License_Manager_Plugin\')) {
    $plugin = Sky_SEO_License_Manager_Plugin::get_instance();
    $api_handler = $plugin->get_api_handler();
    $api_handler->process_license_validation();
} else {
    header(\'Content-Type: application/json\');
    echo json_encode([
        \'authenticated\' => false,
        \'error\' => \'License manager not available\'
    ]);
}';
            
            file_put_contents($endpoint_file, $content);
        }
    }
    
    /**
     * Get all licenses with safe ordering
     */
    public function get_all_licenses($orderby = 'created_at', $order = 'DESC') {
        global $wpdb;
        
        // Whitelist allowed columns to prevent SQL injection
        $allowed_columns = [
            'id',
            'license_key',
            'domain',
            'status',
            'created_at',
            'expires_at',
            'last_check',
            'activation_count',
            'max_activations'
        ];
        
        // Validate orderby column
        if (!in_array($orderby, $allowed_columns, true)) {
            $orderby = 'created_at'; // Default safe value
        }
        
        // Validate order direction
        $order = strtoupper($order);
        if (!in_array($order, ['ASC', 'DESC'], true)) {
            $order = 'DESC'; // Default safe value
        }
        
        // Now it's safe to use these values directly in the query
        $query = "SELECT * FROM {$this->table_name} ORDER BY {$orderby} {$order}";
        
        return $wpdb->get_results($query);
    }
    
    /**
     * Get license by ID
     */
    public function get_license_by_id($id) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $this->table_name WHERE id = %d", $id),
            ARRAY_A
        );
    }
    
    /**
     * Get license by key
     */
    public function get_license_by_key($license_key) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $this->table_name WHERE license_key = %s", $license_key)
        );
    }
    
    /**
     * Save license (insert or update)
     */
    public function save_license($data, $id = null) {
        global $wpdb;
        
        // Normalize domain before saving
        if (isset($data['domain'])) {
            $data['domain'] = $this->normalize_domain($data['domain']);
        }
        
        if ($id) {
            return $wpdb->update($this->table_name, $data, ['id' => $id]);
        } else {
            $data['created_at'] = current_time('mysql');
            return $wpdb->insert($this->table_name, $data);
        }
    }
    
    /**
     * Delete license
     */
    public function delete_license($id) {
        global $wpdb;
        return $wpdb->delete($this->table_name, ['id' => $id]);
    }
    
    /**
     * Update license status
     */
    public function update_license_status($id, $new_status) {
        global $wpdb;
        return $wpdb->update(
            $this->table_name, 
            ['status' => $new_status], 
            ['id' => $id]
        );
    }
    
    /**
     * Update last check time
     */
    public function update_last_check($id) {
        global $wpdb;
        return $wpdb->update(
            $this->table_name,
            ['last_check' => current_time('mysql')],
            ['id' => $id]
        );
    }
    
    /**
     * Get statistics
     */
    public function get_stats() {
        global $wpdb;
        
        return [
            'total' => $wpdb->get_var("SELECT COUNT(*) FROM $this->table_name"),
            'active' => $wpdb->get_var("SELECT COUNT(*) FROM $this->table_name WHERE status = 'active'"),
            'expired' => $wpdb->get_var("SELECT COUNT(*) FROM $this->table_name WHERE expires_at < NOW() AND expires_at != '0000-00-00 00:00:00'")
        ];
    }
    
    /**
     * Centralized domain normalization with comprehensive rules
     */
    public function normalize_domain($domain) {
        if (empty($domain)) {
            return '';
        }
        
        // Convert to lowercase
        $domain = strtolower(trim($domain));
        
        // Remove protocol (http://, https://, ftp://, etc.)
        $domain = preg_replace('#^[a-zA-Z]+://#', '', $domain);
        
        // Remove www. prefix (but not other subdomains)
        $domain = preg_replace('#^www\.#', '', $domain);
        
        // Remove trailing slash and anything after it (paths, query strings)
        $domain = preg_replace('#/.*$#', '', $domain);
        
        // Remove port numbers
        $domain = preg_replace('#:\d+$#', '', $domain);
        
        // Remove any remaining whitespace
        $domain = trim($domain);
        
        // Handle special cases
        if ($domain === 'localhost' || $domain === '127.0.0.1' || $domain === '::1') {
            return 'localhost';
        }
        
        // Validate domain format (basic check)
        if (!preg_match('/^[a-zA-Z0-9.-]+$/', $domain)) {
            return ''; // Invalid domain
        }
        
        return $domain;
    }
    
    /**
     * Check if two domains match (considering wildcards)
     */
    public function domains_match($license_domain, $check_domain) {
        // Normalize both domains
        $license_domain = $this->normalize_domain($license_domain);
        $check_domain = $this->normalize_domain($check_domain);
        
        // Exact match or wildcard
        if ($license_domain === $check_domain || $license_domain === '*') {
            return true;
        }
        
        // Check for subdomain wildcard (*.example.com)
        if (strpos($license_domain, '*.') === 0) {
            $base_domain = substr($license_domain, 2); // Remove *.
            // Check if check_domain ends with base_domain
            return (substr($check_domain, -strlen($base_domain)) === $base_domain);
        }
        
        return false;
    }
    
    /**
     * Get domain from URL
     */
    public function get_domain_from_url($url) {
        if (empty($url)) {
            return '';
        }
        
        // Parse URL
        $parsed = parse_url($url);
        
        if (isset($parsed['host'])) {
            return $this->normalize_domain($parsed['host']);
        }
        
        // If no host found, try to normalize as domain directly
        return $this->normalize_domain($url);
    }
}