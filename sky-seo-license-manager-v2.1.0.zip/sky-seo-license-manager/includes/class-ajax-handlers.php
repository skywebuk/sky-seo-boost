<?php
/**
 * Sky SEO License Manager - AJAX Handlers
 * Handles all AJAX operations
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Sky_License_AJAX_Handlers {
    
    private $db_manager;
    
    public function __construct($db_manager) {
        $this->db_manager = $db_manager;
    }
    
    /**
     * Register all AJAX handlers
     */
    public function register_ajax_handlers() {
        // Admin AJAX handlers
        add_action('wp_ajax_sky_license_save', [$this, 'ajax_save_license']);
        add_action('wp_ajax_sky_license_delete', [$this, 'ajax_delete_license']);
        add_action('wp_ajax_sky_license_toggle', [$this, 'ajax_toggle_license']);
        add_action('wp_ajax_sky_license_get', [$this, 'ajax_get_license']);
        add_action('wp_ajax_sky_license_save_update_info', [$this, 'ajax_save_update_info']);
        add_action('wp_ajax_sky_license_upload_plugin', [$this, 'ajax_upload_plugin']);
        
        // Public AJAX for license validation
        add_action('wp_ajax_nopriv_sky_license_validate', [$this, 'ajax_validate_license']);
        add_action('wp_ajax_sky_license_validate', [$this, 'ajax_validate_license']);
    }
    
    /**
     * AJAX: Save license
     */
    public function ajax_save_license() {
        check_ajax_referer('sky_license_manager_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $license_id = intval($_POST['license_id']);
        $data = [
            'license_key' => sanitize_text_field($_POST['license_key']),
            'domain' => $this->db_manager->normalize_domain($_POST['domain']),
            'status' => sanitize_text_field($_POST['status']),
            'max_activations' => intval($_POST['max_activations']),
            'notes' => sanitize_textarea_field($_POST['notes'])
        ];
        
        if (!empty($_POST['expires_at'])) {
            $data['expires_at'] = sanitize_text_field($_POST['expires_at']);
        }
        
        $result = $this->db_manager->save_license($data, $license_id ?: null);
        
        if ($result !== false) {
            wp_send_json_success(['message' => 'License saved successfully']);
        } else {
            wp_send_json_error(['message' => 'Failed to save license']);
        }
    }
    
    /**
     * AJAX: Delete license
     */
    public function ajax_delete_license() {
        check_ajax_referer('sky_license_manager_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $id = intval($_POST['id']);
        $result = $this->db_manager->delete_license($id);
        
        if ($result) {
            wp_send_json_success(['message' => 'License deleted successfully']);
        } else {
            wp_send_json_error(['message' => 'Failed to delete license']);
        }
    }
    
    /**
     * AJAX: Toggle license status
     */
    public function ajax_toggle_license() {
        check_ajax_referer('sky_license_manager_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $id = intval($_POST['id']);
        $license = $this->db_manager->get_license_by_id($id);
        
        if ($license) {
            $new_status = $license['status'] === 'active' ? 'inactive' : 'active';
            $this->db_manager->update_license_status($id, $new_status);
            wp_send_json_success(['message' => 'License status updated']);
        } else {
            wp_send_json_error(['message' => 'License not found']);
        }
    }
    
    /**
     * AJAX: Get license data
     */
    public function ajax_get_license() {
        check_ajax_referer('sky_license_manager_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $id = intval($_POST['id']);
        $license = $this->db_manager->get_license_by_id($id);
        
        if ($license) {
            wp_send_json_success($license);
        } else {
            wp_send_json_error(['message' => 'License not found']);
        }
    }
    
    /**
     * AJAX: Save update info
     */
    public function ajax_save_update_info() {
        check_ajax_referer('sky_license_manager_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $update_info = [
            'version' => sanitize_text_field($_POST['version']),
            'tested' => sanitize_text_field($_POST['tested']),
            'requires' => sanitize_text_field($_POST['requires']),
            'requires_php' => sanitize_text_field($_POST['requires_php']),
            'info_url' => esc_url_raw($_POST['info_url']),
            'changelog' => sanitize_textarea_field($_POST['changelog'])
        ];
        
        update_option('sky_seo_boost_update_info', $update_info);
        
        wp_send_json_success(['message' => 'Update information saved']);
    }
    
    /**
     * Handle plugin file upload
     */
    public function ajax_upload_plugin() {
        check_ajax_referer('sky_license_manager_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        if (!isset($_FILES['plugin_file'])) {
            wp_send_json_error(['message' => 'No file uploaded']);
        }
        
        $uploaded_file = $_FILES['plugin_file'];
        
        // Validate file type
        $allowed_types = ['application/zip', 'application/x-zip-compressed', 'application/octet-stream'];
        $file_type = $uploaded_file['type'];
        $file_extension = strtolower(pathinfo($uploaded_file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($file_type, $allowed_types) && $file_extension !== 'zip') {
            wp_send_json_error(['message' => 'Invalid file type. Please upload a ZIP file.']);
        }
        
        // Create upload directory
        $upload_dir = wp_upload_dir();
        $license_dir = $upload_dir['basedir'] . '/sky-licenses';
        
        if (!file_exists($license_dir)) {
            wp_mkdir_p($license_dir);
            
            // Create .htaccess to protect directory
            $htaccess_content = "Order Deny,Allow\nDeny from all";
            file_put_contents($license_dir . '/.htaccess', $htaccess_content);
        }
        
        // Move uploaded file
        $destination = $license_dir . '/sky-seo-boost.zip';
        
        if (move_uploaded_file($uploaded_file['tmp_name'], $destination)) {
            update_option('sky_seo_boost_file_path', $destination);
            wp_send_json_success(['message' => 'Plugin file uploaded successfully']);
        } else {
            wp_send_json_error(['message' => 'Failed to upload file']);
        }
    }
    
    /**
     * AJAX: Validate license (public)
     */
    public function ajax_validate_license() {
        $api_handler = new Sky_License_API_Handler($this->db_manager);
        $api_handler->handle_license_validation();
    }
}