<?php
/**
 * Plugin Name: Sky SEO License Manager
 * Plugin URI: https://skywebdesign.co.uk
 * Description: Manage licenses for Sky SEO Boost plugin
 * Version: 2.0.0
 * Author: Sky Web Design
 * License: GPL v2 or later
 * Text Domain: sky-seo-license-manager
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('SKY_LICENSE_MANAGER_VERSION', '2.1.0');
define('SKY_LICENSE_MANAGER_DB_VERSION', '2.0');
define('SKY_LICENSE_MANAGER_TABLE', 'sky_seo_licenses');
define('SKY_LICENSE_MANAGER_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SKY_LICENSE_MANAGER_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SKY_LICENSE_MANAGER_INCLUDES_DIR', SKY_LICENSE_MANAGER_PLUGIN_DIR . 'includes/');
define('SKY_LICENSE_MANAGER_ASSETS_URL', SKY_LICENSE_MANAGER_PLUGIN_URL . 'assets/');

// Include required files in correct order
require_once(SKY_LICENSE_MANAGER_INCLUDES_DIR . 'class-database-manager.php');
require_once(SKY_LICENSE_MANAGER_INCLUDES_DIR . 'class-signature-generator.php');
require_once(SKY_LICENSE_MANAGER_INCLUDES_DIR . 'class-api-handler.php');
require_once(SKY_LICENSE_MANAGER_INCLUDES_DIR . 'class-ajax-handlers.php');
require_once(SKY_LICENSE_MANAGER_INCLUDES_DIR . 'class-admin-pages.php');
require_once(SKY_LICENSE_MANAGER_INCLUDES_DIR . 'class-license-manager-core.php');
require_once(SKY_LICENSE_MANAGER_INCLUDES_DIR . 'class-rest-api.php');

// Initialize the plugin
function sky_license_manager_init() {
    // Load plugin textdomain for translations
    load_plugin_textdomain(
        'sky-seo-license-manager',
        false,
        dirname(plugin_basename(__FILE__)) . '/languages/'
    );

    // Initialize main plugin class
    Sky_SEO_License_Manager_Plugin::get_instance();
}
add_action('plugins_loaded', 'sky_license_manager_init');

// Register REST API routes
function sky_license_manager_register_rest_routes() {
    $db_manager = new Sky_License_Database_Manager();
    $rest_api = new Sky_License_REST_API($db_manager);
    $rest_api->register_routes();
}
add_action('rest_api_init', 'sky_license_manager_register_rest_routes');

// Activation hook
register_activation_hook(__FILE__, 'sky_license_manager_activate');
function sky_license_manager_activate() {
    // Create database manager instance
    $db_manager = new Sky_License_Database_Manager();
    
    // Create database tables
    $db_manager->create_database_tables();
    
    // Create endpoint files
    $db_manager->create_endpoint_files();
    
    // Create upload directory
    $db_manager->create_upload_directory();
    
    // Create legacy endpoint directory if it doesn't exist
    $legacy_dir = SKY_LICENSE_MANAGER_PLUGIN_DIR . 'sky-seo-licenses';
    if (!file_exists($legacy_dir)) {
        wp_mkdir_p($legacy_dir);
    }
    
    // Clear rewrite rules
    flush_rewrite_rules();
    
    // Set default options
    if (!get_option('sky_seo_boost_update_info')) {
        update_option('sky_seo_boost_update_info', [
            'version' => '2.0.0',
            'download_url' => '',
            'info_url' => 'https://skywebdesign.co.uk/plugins/sky-seo-boost',
            'tested' => '6.5',
            'requires' => '5.8',
            'requires_php' => '7.4',
            'changelog' => ''
        ]);
    }
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'sky_license_manager_deactivate');
function sky_license_manager_deactivate() {
    // Clear rewrite rules
    flush_rewrite_rules();
}

// Uninstall hook (only runs when plugin is deleted)
register_uninstall_hook(__FILE__, 'sky_license_manager_uninstall');
function sky_license_manager_uninstall() {
    // Only run if user has permission
    if (!current_user_can('activate_plugins')) {
        return;
    }
    
    // Check if we should delete data on uninstall
    $delete_data = get_option('sky_license_manager_delete_data_on_uninstall', false);
    
    if ($delete_data) {
        global $wpdb;
        
        // Drop tables
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}sky_seo_licenses");
        
        // Delete options
        delete_option('sky_license_manager_db_version');
        delete_option('sky_seo_boost_update_info');
        delete_option('sky_seo_boost_file_path');
        delete_option('sky_license_manager_delete_data_on_uninstall');
        
        // Remove upload directory
        $upload_dir = wp_upload_dir();
        $license_dir = $upload_dir['basedir'] . '/sky-licenses';
        if (file_exists($license_dir)) {
            sky_license_manager_delete_directory($license_dir);
        }
    }
}

// Helper function to recursively delete directory
function sky_license_manager_delete_directory($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    
    if (!is_dir($dir)) {
        return unlink($dir);
    }
    
    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }
        
        if (!sky_license_manager_delete_directory($dir . DIRECTORY_SEPARATOR . $item)) {
            return false;
        }
    }
    
    return rmdir($dir);
}

// Add plugin action links
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'sky_license_manager_action_links');
function sky_license_manager_action_links($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=sky-license-manager') . '">' . __('Manage Licenses', 'sky-seo-license-manager') . '</a>';
    
    array_unshift($links, $settings_link);
    
    return $links;
}

// Add plugin meta links
add_filter('plugin_row_meta', 'sky_license_manager_meta_links', 10, 2);
function sky_license_manager_meta_links($links, $file) {
    if ($file === plugin_basename(__FILE__)) {
        $links[] = '<a href="' . admin_url('admin.php?page=sky-license-api-info') . '">' . __('API Documentation', 'sky-seo-license-manager') . '</a>';
        $links[] = '<a href="https://skywebdesign.co.uk/support" target="_blank">' . __('Support', 'sky-seo-license-manager') . '</a>';
    }
    
    return $links;
}

// Check PHP version compatibility
if (version_compare(PHP_VERSION, '7.0', '<')) {
    add_action('admin_notices', 'sky_license_manager_php_version_notice');
    function sky_license_manager_php_version_notice() {
        ?>
        <div class="notice notice-error">
            <p><?php _e('Sky SEO License Manager requires PHP 7.0 or higher. Please upgrade your PHP version.', 'sky-seo-license-manager'); ?></p>
        </div>
        <?php
    }
}

// Check WordPress version compatibility
if (version_compare(get_bloginfo('version'), '5.0', '<')) {
    add_action('admin_notices', 'sky_license_manager_wp_version_notice');
    function sky_license_manager_wp_version_notice() {
        ?>
        <div class="notice notice-error">
            <p><?php _e('Sky SEO License Manager requires WordPress 5.0 or higher. Please upgrade WordPress.', 'sky-seo-license-manager'); ?></p>
        </div>
        <?php
    }
}