<?php
/**
 * Sky SEO License API Endpoint
 * Production-ready with Imunify360 bypass and improved error handling
 *
 * @package Sky_SEO_License_Manager
 * @version 2.1.1
 */

// CRITICAL: Imunify360 bypass - must be FIRST before any other code
// These tell Imunify360 this is a legitimate API endpoint
if (function_exists('http_response_code')) {
    // Signal to Imunify360 that this is an API endpoint
    @header('X-Imunify360-Skip: 1');
    @header('X-API-Request: license-validation');
}

// Set environment variable for mod_security bypass
if (function_exists('putenv')) {
    @putenv('IMUNIFY360_SKIP=1');
}

// Define as API request for Imunify360
if (!defined('IMUNIFY360_API_REQUEST')) {
    define('IMUNIFY360_API_REQUEST', true);
}

// Prevent output buffering issues
@ini_set('output_buffering', 'Off');
@ini_set('zlib.output_compression', 'Off');

// Disable error display (security)
error_reporting(0);
ini_set('display_errors', 0);

// Clean all existing buffers
while (ob_get_level()) {
    ob_end_clean();
}

// Start fresh buffer
ob_start();

/**
 * Send JSON response and exit
 */
function send_response($data, $code = 200) {
    // Clean buffer
    if (ob_get_level()) {
        ob_clean();
    }
    
    // Set response headers
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    // CORS headers - allow requests from any domain
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Accept, X-Requested-With');
    
    // Security headers
    header('X-Content-Type-Options: nosniff');
    header('X-Robots-Tag: noindex, nofollow');
    
    // Imunify360 bypass headers
    header('X-Imunify360-Skip: 1');
    header('X-API-Response: license-validation');
    
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Validate request origin (basic bot filtering)
 */
function is_valid_request() {
    // Allow if coming from WordPress (has proper user agent)
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    
    // Accept requests from WordPress sites and common HTTP clients
    $valid_agents = [
        'WordPress',
        'Sky SEO',
        'php',
        'curl',
        'Guzzle',
        'HTTP_Request'
    ];
    
    foreach ($valid_agents as $agent) {
        if (stripos($user_agent, $agent) !== false) {
            return true;
        }
    }
    
    // Also accept if it has proper Content-Type header (API request)
    $content_type = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
    if (stripos($content_type, 'application/json') !== false) {
        return true;
    }
    
    // Accept POST requests with body data (legitimate API calls)
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $raw_input = file_get_contents('php://input');
        if (!empty($raw_input)) {
            return true;
        }
    }
    
    // Accept if license parameter is present
    if (!empty($_POST['license']) || !empty($_GET['license'])) {
        return true;
    }
    
    return true; // Default allow - let license validation handle invalid requests
}

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Accept, X-Requested-With');
    header('Access-Control-Max-Age: 86400');
    http_response_code(200);
    exit;
}

// Validate this is a legitimate request
if (!is_valid_request()) {
    send_response([
        'authenticated' => false,
        'error' => 'Invalid request'
    ], 400);
}

// Main license validation logic
try {
    // Load WordPress
    $wp_loaded = false;
    $wp_paths = [
        __DIR__ . '/../../../wp-load.php',
        dirname(dirname(dirname(__DIR__))) . '/wp-load.php',
        $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php'
    ];
    
    foreach ($wp_paths as $path) {
        if (file_exists($path)) {
            define('WP_USE_THEMES', false);
            define('SHORTINIT', false);
            require_once($path);
            $wp_loaded = true;
            break;
        }
    }
    
    if (!$wp_loaded) {
        send_response([
            'authenticated' => false,
            'error' => 'System configuration error'
        ], 500);
    }
    
    // Load signature generator if available
    $signature_generator_path = __DIR__ . '/includes/class-signature-generator.php';
    $signature_available = false;
    if (file_exists($signature_generator_path)) {
        require_once($signature_generator_path);
        $signature_available = class_exists('Sky_License_Signature_Generator');
    }
    
    // Get request data - handle JSON and form data
    $input_data = [];
    
    // Try to read raw input (JSON)
    $raw_input = file_get_contents('php://input');
    if ($raw_input) {
        $json_data = @json_decode($raw_input, true);
        if ($json_data && is_array($json_data)) {
            $input_data = $json_data;
        } else {
            // Try URL-encoded data
            parse_str($raw_input, $parsed_data);
            if (!empty($parsed_data)) {
                $input_data = $parsed_data;
            }
        }
    }
    
    // Merge with POST and GET data
    $input_data = array_merge($input_data, $_POST, $_GET);
    
    // Extract license and domain
    $license = isset($input_data['license']) ? trim($input_data['license']) : '';
    $domain = isset($input_data['domain']) ? trim($input_data['domain']) : '';
    
    // Validate required parameters
    if (empty($license) || empty($domain)) {
        $response = [
            'authenticated' => false,
            'error' => 'Missing required parameters (license and domain are required)',
            'error_code' => 'MISSING_PARAMS'
        ];

        if ($signature_available) {
            $response = Sky_License_Signature_Generator::sign_response($response);
        } else {
            $response['timestamp'] = time();
        }

        send_response($response, 400);
    }
    
    // Normalize domain (must match client-side normalization)
    $domain = strtolower($domain);
    $domain = preg_replace('#^https?://#', '', $domain);
    $domain = preg_replace('#^www\.#', '', $domain);
    $domain = explode('/', $domain)[0];
    $domain = explode(':', $domain)[0];
    $domain = trim($domain);

    // Handle localhost variations
    if (in_array($domain, ['localhost', '127.0.0.1', '::1'])) {
        $domain = 'localhost';
    }

    // Log request for debugging
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log(sprintf(
            'Sky License API: Validation request - License: %s****, Domain: %s, IP: %s',
            substr($license, 0, 4),
            $domain,
            $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ));
    }
    
    // Query license from database
    global $wpdb;
    $table = $wpdb->prefix . 'sky_seo_licenses';
    
    $license_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} WHERE license_key = %s AND status = 'active' LIMIT 1",
        $license
    ));
    
    // License not found or inactive
    if (!$license_data) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log(sprintf('Sky License API: Invalid license key attempted - %s****', substr($license, 0, 4)));
        }

        $response = [
            'authenticated' => false,
            'error' => 'Invalid or inactive license',
            'error_code' => 'INVALID_LICENSE'
        ];

        if ($signature_available) {
            $response = Sky_License_Signature_Generator::sign_response($response);
        } else {
            $response['timestamp'] = time();
        }

        send_response($response, 403);
    }

    // Check expiration
    if (!empty($license_data->expires_at) && $license_data->expires_at !== '0000-00-00 00:00:00') {
        if (strtotime($license_data->expires_at) < time()) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log(sprintf('Sky License API: Expired license attempted - %s', $license_data->expires_at));
            }

            $response = [
                'authenticated' => false,
                'error' => 'License has expired',
                'error_code' => 'LICENSE_EXPIRED',
                'expired_at' => $license_data->expires_at
            ];

            if ($signature_available) {
                $response = Sky_License_Signature_Generator::sign_response($response);
            } else {
                $response['timestamp'] = time();
            }

            send_response($response, 403);
        }
    }
    
    // Check domain authorization
    $lic_domain = strtolower(trim($license_data->domain));
    $lic_domain = preg_replace('#^www\.#', '', $lic_domain);
    $lic_domain = preg_replace('#:\d+$#', '', $lic_domain); // Remove port

    // Normalize localhost for license domain too
    if (in_array($lic_domain, ['localhost', '127.0.0.1', '::1'])) {
        $lic_domain = 'localhost';
    }

    $domain_valid = false;

    // Wildcard - allows any domain
    if ($lic_domain === '*') {
        $domain_valid = true;
    }
    // Exact match
    elseif ($lic_domain === $domain) {
        $domain_valid = true;
    }
    // Subdomain wildcard (*.example.com)
    elseif (strpos($lic_domain, '*.') === 0) {
        $base_domain = substr($lic_domain, 2);
        if ($domain === $base_domain || preg_match('/\.' . preg_quote($base_domain, '/') . '$/', $domain)) {
            $domain_valid = true;
        }
    }

    if (!$domain_valid) {
        // Log domain mismatch for debugging
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log(sprintf(
                'Sky License API: Domain mismatch - License domain: %s, Request domain: %s',
                $lic_domain,
                $domain
            ));
        }

        $response = [
            'authenticated' => false,
            'error' => 'Domain not authorized',
            'error_code' => 'DOMAIN_MISMATCH'
        ];

        if ($signature_available) {
            $response = Sky_License_Signature_Generator::sign_response($response);
        } else {
            $response['timestamp'] = time(); // Always include timestamp
        }

        send_response($response, 403);
    }
    
    // Update last check timestamp
    $wpdb->update(
        $table,
        ['last_check' => current_time('mysql')],
        ['id' => $license_data->id]
    );
    
    // Build success response
    $response = [
        'authenticated' => true,
        'status' => 'active',
        'domain' => $domain
    ];
    
    // Add expiration info if available
    if (!empty($license_data->expires_at) && $license_data->expires_at !== '0000-00-00 00:00:00') {
        $response['expires_at'] = $license_data->expires_at;
        $response['days_remaining'] = max(0, floor((strtotime($license_data->expires_at) - time()) / 86400));
    }
    
    // Add license type if available
    if (!empty($license_data->license_type)) {
        $response['license_type'] = $license_data->license_type;
    }
    
    // Sign the response (this adds timestamp and signature)
    if ($signature_available) {
        $response = Sky_License_Signature_Generator::sign_response($response);
    } else {
        // Always include timestamp even without signature
        $response['timestamp'] = time();
    }

    // Log successful validation
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log(sprintf('Sky License API: Successful validation - Domain: %s', $domain));
    }

    // Send success response
    send_response($response, 200);

} catch (Exception $e) {
    // Log error with full details
    error_log('Sky License API Error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());

    $response = [
        'authenticated' => false,
        'error' => 'Server validation error',
        'error_code' => 'SERVER_ERROR'
    ];

    if (isset($signature_available) && $signature_available) {
        try {
            $response = Sky_License_Signature_Generator::sign_response($response);
        } catch (Exception $sign_error) {
            $response['timestamp'] = time();
        }
    } else {
        $response['timestamp'] = time();
    }

    send_response($response, 500);
}

exit;
